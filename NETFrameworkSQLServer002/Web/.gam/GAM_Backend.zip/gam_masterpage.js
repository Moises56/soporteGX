/*
               File: GAM_MasterPage
        Description: GAM_Master Page
             Author: GeneXus .NET Framework Generator version 18_0_5-175581
       Generated on: 8/24/2023 18:25:37.82
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_masterpage', false, function () {
   this.ServerClass =  "gam_masterpage" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_masterpage.aspx" ;
   this.setObjectType("web");
   this.IsMasterPage=true;
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.AV21TargetURL=gx.fn.getControlValue("vTARGETURL_MPAGE") ;
   };
   this.e150t1_client=function()
   {
      /* Sidebar_Getstate Routine */
      this.clearMessages();
      if ( this.SIDEBAR_MPAGEContainer.isCollapsed )
      {
         gx.fn.setCtrlProperty("CONTAINER_MPAGE","Class", "expandible-container"+" expanded" );
      }
      else
      {
         gx.fn.setCtrlProperty("CONTAINER_MPAGE","Class", "expandible-container" );
      }
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("CONTAINER_MPAGE","Class")',ctrl:'CONTAINER_MPAGE',prop:'Class'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e160t1_client=function()
   {
      /* Sidebar_Itemclick Routine */
      this.clearMessages();
      this.AV21TargetURL =  this.SIDEBAR_MPAGEContainer.SelectedItemTarget  ;
      if ( ! (gx.text.compare('',this.AV21TargetURL)==0) )
      {
         this.callUrl(this.AV21TargetURL);
      }
      this.refreshOutputs([]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e110t2_client=function()
   {
      /* Account_Logout Routine */
      return this.executeServerEvent("ACCOUNT_MPAGE.LOGOUT_MPAGE", false, null, true, true);
   };
   this.e120t2_client=function()
   {
      /* Account_Itemclick Routine */
      return this.executeServerEvent("ACCOUNT_MPAGE.ITEMCLICK_MPAGE", false, null, true, true);
   };
   this.e170t2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER_MPAGE", true, null, false, false);
   };
   this.e180t2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL_MPAGE", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,13,14,16,17,18,19];
   this.GXLastCtrlId =19;
   this.ACCOUNT_MPAGEContainer = gx.uc.getNew(this, 12, 0, "GeneXusUnanimo_Dropdown", "ACCOUNT_MPAGEContainer", "Account", "ACCOUNT_MPAGE");
   var ACCOUNT_MPAGEContainer = this.ACCOUNT_MPAGEContainer;
   ACCOUNT_MPAGEContainer.setProp("Class", "Class", "", "char");
   ACCOUNT_MPAGEContainer.setProp("Enabled", "Enabled", true, "boolean");
   ACCOUNT_MPAGEContainer.setProp("Id", "Id", 0, "num");
   ACCOUNT_MPAGEContainer.setProp("UserPhoto", "Userphoto", "", "str");
   ACCOUNT_MPAGEContainer.setDynProp("UserFullName", "Userfullname", "", "str");
   ACCOUNT_MPAGEContainer.setProp("UserCompany", "Usercompany", "", "str");
   ACCOUNT_MPAGEContainer.setProp("DisplayType", "Displaytype", "Text", "str");
   ACCOUNT_MPAGEContainer.setProp("ExpandBehavior", "Expandbehavior", "Hover", "str");
   ACCOUNT_MPAGEContainer.setProp("ShowVerticalSeparator", "Showverticalseparator", true, "bool");
   ACCOUNT_MPAGEContainer.setProp("ShowLogoutOption", "Showlogoutoption", true, "bool");
   ACCOUNT_MPAGEContainer.setDynProp("LogoutIcon", "Logouticon", "", "str");
   ACCOUNT_MPAGEContainer.addV2CFunction('AV7DropdownItems', "vDROPDOWNITEMS_MPAGE", 'setDropdownItems');
   ACCOUNT_MPAGEContainer.addC2VFunction(function(UC) { UC.ParentObject.AV7DropdownItems=UC.getDropdownItems();gx.fn.setControlValue("vDROPDOWNITEMS_MPAGE",UC.ParentObject.AV7DropdownItems); });
   ACCOUNT_MPAGEContainer.setProp("DropdownItemsCurrentIndex", "Dropdownitemscurrentindex", 0, "num");
   ACCOUNT_MPAGEContainer.setProp("SelectedItemId", "Selecteditemid", "", "str");
   ACCOUNT_MPAGEContainer.setProp("SelectedItemTarget", "Selecteditemtarget", "", "str");
   ACCOUNT_MPAGEContainer.setProp("Visible", "Visible", true, "bool");
   ACCOUNT_MPAGEContainer.setC2ShowFunction(function(UC) { UC.show(); });
   ACCOUNT_MPAGEContainer.addEventHandler("Logout", this.e110t2_client);
   ACCOUNT_MPAGEContainer.addEventHandler("ItemClick", this.e120t2_client);
   this.setUserControl(ACCOUNT_MPAGEContainer);
   this.SIDEBAR_MPAGEContainer = gx.uc.getNew(this, 15, 0, "GeneXusUnanimo_Sidebar", "SIDEBAR_MPAGEContainer", "Sidebar", "SIDEBAR_MPAGE");
   var SIDEBAR_MPAGEContainer = this.SIDEBAR_MPAGEContainer;
   SIDEBAR_MPAGEContainer.setProp("Enabled", "Enabled", true, "boolean");
   SIDEBAR_MPAGEContainer.setProp("Title", "Title", "", "str");
   SIDEBAR_MPAGEContainer.setProp("Class", "Class", "ch-sidebar", "str");
   SIDEBAR_MPAGEContainer.setProp("FooterText", "Footertext", "", "str");
   SIDEBAR_MPAGEContainer.setProp("DistanceToTop", "Distancetotop", 60, "num");
   SIDEBAR_MPAGEContainer.setProp("Collapsible", "Collapsible", true, "bool");
   SIDEBAR_MPAGEContainer.addV2CFunction('AV18SidebarItems', "vSIDEBARITEMS_MPAGE", 'setSidebarItems');
   SIDEBAR_MPAGEContainer.addC2VFunction(function(UC) { UC.ParentObject.AV18SidebarItems=UC.getSidebarItems();gx.fn.setControlValue("vSIDEBARITEMS_MPAGE",UC.ParentObject.AV18SidebarItems); });
   SIDEBAR_MPAGEContainer.setProp("SidebarItemsCurrentIndex", "Sidebaritemscurrentindex", 0, "num");
   SIDEBAR_MPAGEContainer.setProp("ActiveItemId", "Activeitemid", "", "str");
   SIDEBAR_MPAGEContainer.setProp("SelectedItemTarget", "Selecteditemtarget", "", "str");
   SIDEBAR_MPAGEContainer.setProp("isCollapsed", "Iscollapsed", false, "bool");
   SIDEBAR_MPAGEContainer.setProp("IconAutoColor", "Iconautocolor", false, "bool");
   SIDEBAR_MPAGEContainer.setDynProp("Visible", "Visible", true, "bool");
   SIDEBAR_MPAGEContainer.setC2ShowFunction(function(UC) { UC.show(); });
   SIDEBAR_MPAGEContainer.addEventHandler("ItemClick", this.e160t1_client);
   SIDEBAR_MPAGEContainer.addEventHandler("GetState", this.e150t1_client);
   this.setUserControl(SIDEBAR_MPAGEContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"HEADER",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"MENUICON",grid:0};
   GXValidFnc[9]={ id: 9, fld:"",grid:0};
   GXValidFnc[10]={ id: 10, fld:"LOGO",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id: 14, fld:"",grid:0};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"CONTAINER",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   this.AV7DropdownItems = [ ] ;
   this.AV18SidebarItems = [ ] ;
   this.AV21TargetURL = "" ;
   this.Events = {"e110t2_client": ["ACCOUNT_MPAGE.LOGOUT_MPAGE", true] ,"e120t2_client": ["ACCOUNT_MPAGE.ITEMCLICK_MPAGE", true] ,"e170t2_client": ["ENTER_MPAGE", true] ,"e180t2_client": ["CANCEL_MPAGE", true] ,"e150t1_client": ["SIDEBAR_MPAGE.GETSTATE_MPAGE", false] ,"e160t1_client": ["SIDEBAR_MPAGE.ITEMCLICK_MPAGE", false]};
   this.EvtParms["REFRESH_MPAGE"] = [[],[]];
   this.EvtParms["ACCOUNT_MPAGE.LOGOUT_MPAGE"] = [[],[]];
   this.EvtParms["SIDEBAR_MPAGE.GETSTATE_MPAGE"] = [[{av:'this.SIDEBAR_MPAGEContainer.isCollapsed',ctrl:'SIDEBAR_MPAGE',prop:'isCollapsed'}],[{av:'gx.fn.getCtrlProperty("CONTAINER_MPAGE","Class")',ctrl:'CONTAINER_MPAGE',prop:'Class'}]];
   this.EvtParms["SIDEBAR_MPAGE.ITEMCLICK_MPAGE"] = [[{av:'this.SIDEBAR_MPAGEContainer.SelectedItemTarget',ctrl:'SIDEBAR_MPAGE',prop:'SelectedItemTarget'}],[]];
   this.EvtParms["ACCOUNT_MPAGE.ITEMCLICK_MPAGE"] = [[{av:'this.ACCOUNT_MPAGEContainer.SelectedItemId',ctrl:'ACCOUNT_MPAGE',prop:'SelectedItemId'}],[]];
   this.EvtParms["ENTER_MPAGE"] = [[],[]];
   this.setVCMap("AV21TargetURL", "vTARGETURL_MPAGE", 0, "svchar", 256, 0);
   this.Initialize( );
});
gx.wi( function() { gx.createMasterPage(gam_masterpage);});
