/*
               File: GAM_Messages
        Description: GAM_Messages
             Author: GeneXus .NET Framework Generator version 18_0_5-175581
       Generated on: 8/24/2023 18:23:53.78
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_messages', true, function (CmpContext) {
   this.ServerClass =  "gam_messages" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_messages.aspx" ;
   this.setObjectType("web");
   this.setCmpContext(CmpContext);
   this.ReadonlyForm = true;
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
   };
   this.e13341_client=function()
   {
      /* Messages_Close Routine */
      this.clearMessages();
      this.MESSAGESContainer.Visible =  false  ;
      this.refreshOutputs([{ctrl:this.MESSAGESContainer}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e14342_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e15342_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5];
   this.GXLastCtrlId =5;
   this.MESSAGESContainer = gx.uc.getNew(this, 6, 0, "GeneXusUnanimo_Alert", this.CmpContext + "MESSAGESContainer", "Messages", "MESSAGES");
   var MESSAGESContainer = this.MESSAGESContainer;
   MESSAGESContainer.setProp("Class", "Class", "", "char");
   MESSAGESContainer.setProp("Enabled", "Enabled", true, "boolean");
   MESSAGESContainer.setProp("id", "Id", "1", "str");
   MESSAGESContainer.setDynProp("Type", "Type", "info", "str");
   MESSAGESContainer.setDynProp("Title", "Title", "", "str");
   MESSAGESContainer.setDynProp("Message", "Message", "", "str");
   MESSAGESContainer.setProp("Position", "Position", "Fixed to bottom", "str");
   MESSAGESContainer.setDynProp("ShowMultiple", "Showmultiple", false, "bool");
   MESSAGESContainer.setDynProp("Count", "Count", 0, "num");
   MESSAGESContainer.setDynProp("Visible", "Visible", true, "bool");
   MESSAGESContainer.setC2ShowFunction(function(UC) { UC.show(); });
   MESSAGESContainer.addEventHandler("Close", this.e13341_client);
   this.setUserControl(MESSAGESContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   this.Events = {"e14342_client": ["ENTER", true] ,"e15342_client": ["CANCEL", true] ,"e13341_client": ["MESSAGES.CLOSE", false]};
   this.EvtParms["REFRESH"] = [[],[]];
   this.EvtParms["MESSAGES.CLOSE"] = [[],[{av:'this.MESSAGESContainer.Visible',ctrl:'MESSAGES',prop:'Visible'}]];
   this.EvtParms["ENTER"] = [[],[]];
   this.Initialize( );
});
