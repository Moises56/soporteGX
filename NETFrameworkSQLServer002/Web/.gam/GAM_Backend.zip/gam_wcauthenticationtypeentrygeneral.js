/*
               File: GAM_WCAuthenticationTypeEntryGeneral
        Description: Authentication Type Entry General
             Author: GeneXus .NET Framework Generator version 18_0_5-175581
       Generated on: 8/24/2023 18:27:25.46
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_wcauthenticationtypeentrygeneral', true, function (CmpContext) {
   this.ServerClass =  "gam_wcauthenticationtypeentrygeneral" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_wcauthenticationtypeentrygeneral.aspx" ;
   this.setObjectType("web");
   this.setCmpContext(CmpContext);
   this.ReadonlyForm = true;
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.Gx_mode=gx.fn.getControlValue("vMODE") ;
   };
   this.Validv_Functionid=function()
   {
      return this.validCliEvt("Validv_Functionid", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vFUNCTIONID");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV28FunctionId , "AuthenticationAndRoles" ) == 0 || gx.text.compare( this.AV28FunctionId , "OnlyAuthentication" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Function Id"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Otpgenerationtype=function()
   {
      return this.validCliEvt("Validv_Otpgenerationtype", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vOTPGENERATIONTYPE");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV70OTPGenerationType , "gam" ) == 0 || gx.text.compare( this.AV70OTPGenerationType , "custom" ) == 0 || gx.text.compare( this.AV70OTPGenerationType , "totp" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Generation type"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Wsversion=function()
   {
      return this.validCliEvt("Validv_Wsversion", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vWSVERSION");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV47WSVersion , "GAM10" ) == 0 || gx.text.compare( this.AV47WSVersion , "GAM20" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "WSVersion"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Cusversion=function()
   {
      return this.validCliEvt("Validv_Cusversion", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vCUSVERSION");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV24CusVersion , "GAM10" ) == 0 || gx.text.compare( this.AV24CusVersion , "GAM20" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Cus Version"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.s232_client=function()
   {
      /* 'SHOWMESSAGES' Routine */
      this.createWebComponent('Wcmessages','GAM_Messages',[]);
   };
   this.e122q2_client=function()
   {
      /* 'Confirm' Routine */
      return this.executeServerEvent("'CONFIRM'", false, null, false, false);
   };
   this.e132q2_client=function()
   {
      /* 'GenerateKey' Routine */
      return this.executeServerEvent("'GENERATEKEY'", false, null, false, false);
   };
   this.e142q2_client=function()
   {
      /* 'GenerateKeyCustom' Routine */
      return this.executeServerEvent("'GENERATEKEYCUSTOM'", false, null, false, false);
   };
   this.e152q2_client=function()
   {
      /* Tfaenable_Click Routine */
      return this.executeServerEvent("VTFAENABLE.CLICK", true, null, false, true);
   };
   this.e162q2_client=function()
   {
      /* Otpgenerationtype_Click Routine */
      return this.executeServerEvent("VOTPGENERATIONTYPE.CLICK", true, null, false, true);
   };
   this.e172q2_client=function()
   {
      /* 'Cancel' Routine */
      return this.executeServerEvent("'CANCEL'", false, null, false, false);
   };
   this.e192q2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e202q2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,255,256,257,258,259,260,261,262,263,264,265,266,267,268,269,270,271,272,273,274,275,276,277,278,279,280,281,282,283,284,285,286,287,288,289,290,291,292,293,294,295,296,297,298,299,300,301,302,303,304,305,306,307,308,309,310,311,312,313,314,315,316,317,318,319,320,321,322,323,324,325,326,327,328,329,330,331,332,333,334,335,336,337,338,339,340,341,342,343,344,345,346,347,348,349,350,351,352,353,354,355,356,357,358,359,360,361,362,363,364,365,366,367,368,369,370,371,372,373,374,375,376,377,378,379,380,381,382,383,384,385,386,387,388,389,390,391,392,393,394,395,396,397,398,399,400,401,403,404,405,406,407,408,409,410,411,412];
   this.GXLastCtrlId =412;
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TABLE1",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"TABLEGENERALTITLE",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"TBTITLEGENERAL", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id: 14, fld:"",grid:0};
   GXValidFnc[15]={ id: 15, fld:"TABLEDATAGENERAL",grid:0};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id:20 ,lvl:0,type:"char",len:30,dec:0,sign:false,ro:1,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vTYPEID",fmt:0,gxz:"ZV37TypeId",gxold:"OV37TypeId",gxvar:"AV37TypeId",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV37TypeId=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV37TypeId=Value},v2c:function(){gx.fn.setComboBoxValue("vTYPEID",gx.O.AV37TypeId);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV37TypeId=this.val()},val:function(){return gx.fn.getControlValue("vTYPEID")},nac:gx.falseFn};
   this.declareDomainHdlr( 20 , function() {
   });
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[25]={ id:25 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:1,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",fmt:0,gxz:"ZV34Name",gxold:"OV34Name",gxvar:"AV34Name",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV34Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV34Name=Value},v2c:function(){gx.fn.setControlValue("vNAME",gx.O.AV34Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV34Name=this.val()},val:function(){return gx.fn.getControlValue("vNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 25 , function() {
   });
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id: 28, fld:"",grid:0};
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[30]={ id:30 ,lvl:0,type:"char",len:30,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Functionid,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFUNCTIONID",fmt:0,gxz:"ZV28FunctionId",gxold:"OV28FunctionId",gxvar:"AV28FunctionId",ucs:[],op:[30],ip:[30],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV28FunctionId=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV28FunctionId=Value},v2c:function(){gx.fn.setComboBoxValue("vFUNCTIONID",gx.O.AV28FunctionId);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV28FunctionId=this.val()},val:function(){return gx.fn.getControlValue("vFUNCTIONID")},nac:gx.falseFn};
   this.declareDomainHdlr( 30 , function() {
   });
   GXValidFnc[31]={ id: 31, fld:"",grid:0};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[35]={ id:35 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vISENABLE",fmt:0,gxz:"ZV33IsEnable",gxold:"OV33IsEnable",gxvar:"AV33IsEnable",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV33IsEnable=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV33IsEnable=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vISENABLE",gx.O.AV33IsEnable,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV33IsEnable=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vISENABLE")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 35 , function() {
   });
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[37]={ id: 37, fld:"",grid:0};
   GXValidFnc[38]={ id: 38, fld:"",grid:0};
   GXValidFnc[39]={ id: 39, fld:"",grid:0};
   GXValidFnc[40]={ id:40 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDSC",fmt:0,gxz:"ZV25Dsc",gxold:"OV25Dsc",gxvar:"AV25Dsc",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV25Dsc=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV25Dsc=Value},v2c:function(){gx.fn.setControlValue("vDSC",gx.O.AV25Dsc,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV25Dsc=this.val()},val:function(){return gx.fn.getControlValue("vDSC")},nac:gx.falseFn};
   this.declareDomainHdlr( 40 , function() {
   });
   GXValidFnc[41]={ id: 41, fld:"",grid:0};
   GXValidFnc[42]={ id: 42, fld:"",grid:0};
   GXValidFnc[43]={ id: 43, fld:"",grid:0};
   GXValidFnc[44]={ id: 44, fld:"",grid:0};
   GXValidFnc[45]={ id:45 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSMALLIMAGENAME",fmt:0,gxz:"ZV36SmallImageName",gxold:"OV36SmallImageName",gxvar:"AV36SmallImageName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV36SmallImageName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV36SmallImageName=Value},v2c:function(){gx.fn.setControlValue("vSMALLIMAGENAME",gx.O.AV36SmallImageName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV36SmallImageName=this.val()},val:function(){return gx.fn.getControlValue("vSMALLIMAGENAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 45 , function() {
   });
   GXValidFnc[46]={ id: 46, fld:"",grid:0};
   GXValidFnc[47]={ id: 47, fld:"",grid:0};
   GXValidFnc[48]={ id: 48, fld:"",grid:0};
   GXValidFnc[49]={ id: 49, fld:"",grid:0};
   GXValidFnc[50]={ id:50 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBIGIMAGENAME",fmt:0,gxz:"ZV14BigImageName",gxold:"OV14BigImageName",gxvar:"AV14BigImageName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV14BigImageName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV14BigImageName=Value},v2c:function(){gx.fn.setControlValue("vBIGIMAGENAME",gx.O.AV14BigImageName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV14BigImageName=this.val()},val:function(){return gx.fn.getControlValue("vBIGIMAGENAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 50 , function() {
   });
   GXValidFnc[51]={ id: 51, fld:"",grid:0};
   GXValidFnc[52]={ id: 52, fld:"",grid:0};
   GXValidFnc[53]={ id: 53, fld:"",grid:0};
   GXValidFnc[54]={ id: 54, fld:"",grid:0};
   GXValidFnc[55]={ id:55 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vIMPERSONATE",fmt:0,gxz:"ZV32Impersonate",gxold:"OV32Impersonate",gxvar:"AV32Impersonate",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV32Impersonate=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV32Impersonate=Value},v2c:function(){gx.fn.setComboBoxValue("vIMPERSONATE",gx.O.AV32Impersonate);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV32Impersonate=this.val()},val:function(){return gx.fn.getControlValue("vIMPERSONATE")},nac:gx.falseFn};
   this.declareDomainHdlr( 55 , function() {
   });
   GXValidFnc[56]={ id: 56, fld:"",grid:0};
   GXValidFnc[57]={ id: 57, fld:"TABLE3",grid:0};
   GXValidFnc[58]={ id: 58, fld:"",grid:0};
   GXValidFnc[59]={ id: 59, fld:"",grid:0};
   GXValidFnc[60]={ id: 60, fld:"TABLE4",grid:0};
   GXValidFnc[61]={ id: 61, fld:"",grid:0};
   GXValidFnc[62]={ id: 62, fld:"",grid:0};
   GXValidFnc[63]={ id: 63, fld:"TEXTBLOCK1", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[64]={ id: 64, fld:"",grid:0};
   GXValidFnc[65]={ id: 65, fld:"",grid:0};
   GXValidFnc[66]={ id: 66, fld:"TABLE5",grid:0};
   GXValidFnc[67]={ id: 67, fld:"",grid:0};
   GXValidFnc[68]={ id: 68, fld:"",grid:0};
   GXValidFnc[69]={ id: 69, fld:"TABLE2",grid:0};
   GXValidFnc[70]={ id: 70, fld:"",grid:0};
   GXValidFnc[71]={ id: 71, fld:"",grid:0};
   GXValidFnc[72]={ id: 72, fld:"TBLOTPAUTHENTICATION",grid:0};
   GXValidFnc[73]={ id: 73, fld:"",grid:0};
   GXValidFnc[74]={ id: 74, fld:"",grid:0};
   GXValidFnc[75]={ id: 75, fld:"",grid:0};
   GXValidFnc[76]={ id: 76, fld:"",grid:0};
   GXValidFnc[77]={ id:77 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vOTPUSEFORFIRSTFACTORAUTHENTICATION",fmt:0,gxz:"ZV79OTPUseForFirstFactorAuthentication",gxold:"OV79OTPUseForFirstFactorAuthentication",gxvar:"AV79OTPUseForFirstFactorAuthentication",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV79OTPUseForFirstFactorAuthentication=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV79OTPUseForFirstFactorAuthentication=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vOTPUSEFORFIRSTFACTORAUTHENTICATION",gx.O.AV79OTPUseForFirstFactorAuthentication,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV79OTPUseForFirstFactorAuthentication=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vOTPUSEFORFIRSTFACTORAUTHENTICATION")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 77 , function() {
   });
   GXValidFnc[78]={ id: 78, fld:"",grid:0};
   GXValidFnc[79]={ id: 79, fld:"",grid:0};
   GXValidFnc[80]={ id: 80, fld:"TBLOTPCONFIGURATION",grid:0};
   GXValidFnc[81]={ id: 81, fld:"",grid:0};
   GXValidFnc[82]={ id: 82, fld:"",grid:0};
   GXValidFnc[83]={ id: 83, fld:"",grid:0};
   GXValidFnc[84]={ id: 84, fld:"",grid:0};
   GXValidFnc[85]={ id:85 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vOTPEVENTVALIDATEUSER",fmt:0,gxz:"ZV68OTPEventValidateUser",gxold:"OV68OTPEventValidateUser",gxvar:"AV68OTPEventValidateUser",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV68OTPEventValidateUser=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV68OTPEventValidateUser=Value},v2c:function(){gx.fn.setComboBoxValue("vOTPEVENTVALIDATEUSER",gx.O.AV68OTPEventValidateUser);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV68OTPEventValidateUser=this.val()},val:function(){return gx.fn.getControlValue("vOTPEVENTVALIDATEUSER")},nac:gx.falseFn};
   this.declareDomainHdlr( 85 , function() {
   });
   GXValidFnc[86]={ id: 86, fld:"",grid:0};
   GXValidFnc[87]={ id: 87, fld:"",grid:0};
   GXValidFnc[88]={ id: 88, fld:"",grid:0};
   GXValidFnc[89]={ id: 89, fld:"",grid:0};
   GXValidFnc[90]={ id:90 ,lvl:0,type:"svchar",len:20,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Otpgenerationtype,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vOTPGENERATIONTYPE",fmt:0,gxz:"ZV70OTPGenerationType",gxold:"OV70OTPGenerationType",gxvar:"AV70OTPGenerationType",ucs:[],op:[90],ip:[90],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV70OTPGenerationType=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV70OTPGenerationType=Value},v2c:function(){gx.fn.setComboBoxValue("vOTPGENERATIONTYPE",gx.O.AV70OTPGenerationType);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV70OTPGenerationType=this.val()},val:function(){return gx.fn.getControlValue("vOTPGENERATIONTYPE")},nac:gx.falseFn,evt:"e162q2_client"};
   this.declareDomainHdlr( 90 , function() {
   });
   GXValidFnc[91]={ id: 91, fld:"",grid:0};
   GXValidFnc[92]={ id: 92, fld:"",grid:0};
   GXValidFnc[93]={ id: 93, fld:"TBLOTPCUSTOM",grid:0};
   GXValidFnc[94]={ id: 94, fld:"",grid:0};
   GXValidFnc[95]={ id: 95, fld:"",grid:0};
   GXValidFnc[96]={ id: 96, fld:"",grid:0};
   GXValidFnc[97]={ id: 97, fld:"",grid:0};
   GXValidFnc[98]={ id:98 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vOTPGENERATIONTYPE_CUSTOMEVENTGENERATECODE",fmt:0,gxz:"ZV71OTPGenerationType_CustomEventGenerateCode",gxold:"OV71OTPGenerationType_CustomEventGenerateCode",gxvar:"AV71OTPGenerationType_CustomEventGenerateCode",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV71OTPGenerationType_CustomEventGenerateCode=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV71OTPGenerationType_CustomEventGenerateCode=Value},v2c:function(){gx.fn.setComboBoxValue("vOTPGENERATIONTYPE_CUSTOMEVENTGENERATECODE",gx.O.AV71OTPGenerationType_CustomEventGenerateCode);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV71OTPGenerationType_CustomEventGenerateCode=this.val()},val:function(){return gx.fn.getControlValue("vOTPGENERATIONTYPE_CUSTOMEVENTGENERATECODE")},nac:gx.falseFn};
   this.declareDomainHdlr( 98 , function() {
   });
   GXValidFnc[99]={ id: 99, fld:"",grid:0};
   GXValidFnc[100]={ id: 100, fld:"",grid:0};
   GXValidFnc[101]={ id: 101, fld:"TBLTYPEOTPGENERATECODE",grid:0};
   GXValidFnc[102]={ id: 102, fld:"",grid:0};
   GXValidFnc[103]={ id: 103, fld:"",grid:0};
   GXValidFnc[104]={ id: 104, fld:"",grid:0};
   GXValidFnc[105]={ id: 105, fld:"",grid:0};
   GXValidFnc[106]={ id:106 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vOTPAUTOGENERATEDCODELENGTH",fmt:0,gxz:"ZV63OTPAutogeneratedCodeLength",gxold:"OV63OTPAutogeneratedCodeLength",gxvar:"AV63OTPAutogeneratedCodeLength",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV63OTPAutogeneratedCodeLength=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV63OTPAutogeneratedCodeLength=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vOTPAUTOGENERATEDCODELENGTH",gx.O.AV63OTPAutogeneratedCodeLength,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV63OTPAutogeneratedCodeLength=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vOTPAUTOGENERATEDCODELENGTH",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[107]={ id: 107, fld:"",grid:0};
   GXValidFnc[108]={ id: 108, fld:"",grid:0};
   GXValidFnc[109]={ id: 109, fld:"",grid:0};
   GXValidFnc[110]={ id: 110, fld:"",grid:0};
   GXValidFnc[111]={ id:111 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vOTPGENERATECODEONLYNUMBERS",fmt:0,gxz:"ZV69OTPGenerateCodeOnlyNumbers",gxold:"OV69OTPGenerateCodeOnlyNumbers",gxvar:"AV69OTPGenerateCodeOnlyNumbers",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV69OTPGenerateCodeOnlyNumbers=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV69OTPGenerateCodeOnlyNumbers=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vOTPGENERATECODEONLYNUMBERS",gx.O.AV69OTPGenerateCodeOnlyNumbers,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV69OTPGenerateCodeOnlyNumbers=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vOTPGENERATECODEONLYNUMBERS")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 111 , function() {
   });
   GXValidFnc[112]={ id: 112, fld:"",grid:0};
   GXValidFnc[113]={ id: 113, fld:"",grid:0};
   GXValidFnc[114]={ id: 114, fld:"",grid:0};
   GXValidFnc[115]={ id: 115, fld:"",grid:0};
   GXValidFnc[116]={ id:116 ,lvl:0,type:"int",len:9,dec:0,sign:false,pic:"ZZZZZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vOTPCODEEXPIRATIONTIMEOUT",fmt:0,gxz:"ZV65OTPCodeExpirationTimeout",gxold:"OV65OTPCodeExpirationTimeout",gxvar:"AV65OTPCodeExpirationTimeout",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV65OTPCodeExpirationTimeout=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV65OTPCodeExpirationTimeout=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vOTPCODEEXPIRATIONTIMEOUT",gx.O.AV65OTPCodeExpirationTimeout,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV65OTPCodeExpirationTimeout=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vOTPCODEEXPIRATIONTIMEOUT",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[117]={ id: 117, fld:"",grid:0};
   GXValidFnc[118]={ id: 118, fld:"",grid:0};
   GXValidFnc[119]={ id: 119, fld:"",grid:0};
   GXValidFnc[120]={ id: 120, fld:"",grid:0};
   GXValidFnc[121]={ id:121 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vOTPMAXIMUMDAILYNUMBERCODES",fmt:0,gxz:"ZV76OTPMaximumDailyNumberCodes",gxold:"OV76OTPMaximumDailyNumberCodes",gxvar:"AV76OTPMaximumDailyNumberCodes",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV76OTPMaximumDailyNumberCodes=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV76OTPMaximumDailyNumberCodes=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vOTPMAXIMUMDAILYNUMBERCODES",gx.O.AV76OTPMaximumDailyNumberCodes,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV76OTPMaximumDailyNumberCodes=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vOTPMAXIMUMDAILYNUMBERCODES",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[122]={ id: 122, fld:"",grid:0};
   GXValidFnc[123]={ id: 123, fld:"",grid:0};
   GXValidFnc[124]={ id: 124, fld:"",grid:0};
   GXValidFnc[125]={ id: 125, fld:"",grid:0};
   GXValidFnc[126]={ id:126 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vOTPNUMBERUNSUCCESSFULRETRIESTOLOCKOTP",fmt:0,gxz:"ZV78OTPNumberUnsuccessfulRetriesToLockOTP",gxold:"OV78OTPNumberUnsuccessfulRetriesToLockOTP",gxvar:"AV78OTPNumberUnsuccessfulRetriesToLockOTP",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV78OTPNumberUnsuccessfulRetriesToLockOTP=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV78OTPNumberUnsuccessfulRetriesToLockOTP=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vOTPNUMBERUNSUCCESSFULRETRIESTOLOCKOTP",gx.O.AV78OTPNumberUnsuccessfulRetriesToLockOTP,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV78OTPNumberUnsuccessfulRetriesToLockOTP=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vOTPNUMBERUNSUCCESSFULRETRIESTOLOCKOTP",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[127]={ id: 127, fld:"",grid:0};
   GXValidFnc[128]={ id: 128, fld:"",grid:0};
   GXValidFnc[129]={ id: 129, fld:"",grid:0};
   GXValidFnc[130]={ id: 130, fld:"",grid:0};
   GXValidFnc[131]={ id:131 ,lvl:0,type:"int",len:9,dec:0,sign:false,pic:"ZZZZZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vOTPAUTOUNLOCKTIME",fmt:0,gxz:"ZV64OTPAutoUnlockTime",gxold:"OV64OTPAutoUnlockTime",gxvar:"AV64OTPAutoUnlockTime",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV64OTPAutoUnlockTime=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV64OTPAutoUnlockTime=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vOTPAUTOUNLOCKTIME",gx.O.AV64OTPAutoUnlockTime,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV64OTPAutoUnlockTime=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vOTPAUTOUNLOCKTIME",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[132]={ id: 132, fld:"",grid:0};
   GXValidFnc[133]={ id: 133, fld:"",grid:0};
   GXValidFnc[134]={ id: 134, fld:"",grid:0};
   GXValidFnc[135]={ id: 135, fld:"",grid:0};
   GXValidFnc[136]={ id:136 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vOTPNUMBERUNSUCCESSFULRETRIESTOBLOCKUSERBASEDOFOTPLOCKS",fmt:0,gxz:"ZV77OTPNumberUnsuccessfulRetriesToBlockUserBasedOfOTPLocks",gxold:"OV77OTPNumberUnsuccessfulRetriesToBlockUserBasedOfOTPLocks",gxvar:"AV77OTPNumberUnsuccessfulRetriesToBlockUserBasedOfOTPLocks",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV77OTPNumberUnsuccessfulRetriesToBlockUserBasedOfOTPLocks=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV77OTPNumberUnsuccessfulRetriesToBlockUserBasedOfOTPLocks=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vOTPNUMBERUNSUCCESSFULRETRIESTOBLOCKUSERBASEDOFOTPLOCKS",gx.O.AV77OTPNumberUnsuccessfulRetriesToBlockUserBasedOfOTPLocks,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV77OTPNumberUnsuccessfulRetriesToBlockUserBasedOfOTPLocks=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vOTPNUMBERUNSUCCESSFULRETRIESTOBLOCKUSERBASEDOFOTPLOCKS",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[137]={ id: 137, fld:"",grid:0};
   GXValidFnc[138]={ id: 138, fld:"",grid:0};
   GXValidFnc[139]={ id: 139, fld:"TBLSENDANDVALIDATEOTPCODE",grid:0};
   GXValidFnc[140]={ id: 140, fld:"",grid:0};
   GXValidFnc[141]={ id: 141, fld:"",grid:0};
   GXValidFnc[142]={ id: 142, fld:"",grid:0};
   GXValidFnc[143]={ id: 143, fld:"",grid:0};
   GXValidFnc[144]={ id:144 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vOTPEVENTSENDCODE",fmt:0,gxz:"ZV66OTPEventSendCode",gxold:"OV66OTPEventSendCode",gxvar:"AV66OTPEventSendCode",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV66OTPEventSendCode=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV66OTPEventSendCode=Value},v2c:function(){gx.fn.setComboBoxValue("vOTPEVENTSENDCODE",gx.O.AV66OTPEventSendCode);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV66OTPEventSendCode=this.val()},val:function(){return gx.fn.getControlValue("vOTPEVENTSENDCODE")},nac:gx.falseFn};
   this.declareDomainHdlr( 144 , function() {
   });
   GXValidFnc[145]={ id: 145, fld:"",grid:0};
   GXValidFnc[146]={ id: 146, fld:"",grid:0};
   GXValidFnc[147]={ id: 147, fld:"TBLSENDEMAILBYGAM",grid:0};
   GXValidFnc[148]={ id: 148, fld:"",grid:0};
   GXValidFnc[149]={ id: 149, fld:"",grid:0};
   GXValidFnc[150]={ id: 150, fld:"",grid:0};
   GXValidFnc[151]={ id: 151, fld:"",grid:0};
   GXValidFnc[152]={ id:152 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vOTPMAILMESSAGESUBJECT",fmt:0,gxz:"ZV75OTPMailMessageSubject",gxold:"OV75OTPMailMessageSubject",gxvar:"AV75OTPMailMessageSubject",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV75OTPMailMessageSubject=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV75OTPMailMessageSubject=Value},v2c:function(){gx.fn.setControlValue("vOTPMAILMESSAGESUBJECT",gx.O.AV75OTPMailMessageSubject,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV75OTPMailMessageSubject=this.val()},val:function(){return gx.fn.getControlValue("vOTPMAILMESSAGESUBJECT")},nac:gx.falseFn};
   this.declareDomainHdlr( 152 , function() {
   });
   GXValidFnc[153]={ id: 153, fld:"",grid:0};
   GXValidFnc[154]={ id: 154, fld:"",grid:0};
   GXValidFnc[155]={ id: 155, fld:"",grid:0};
   GXValidFnc[156]={ id: 156, fld:"",grid:0};
   GXValidFnc[157]={ id:157 ,lvl:0,type:"svchar",len:2048,dec:100,sign:false,ro:0,multiline:true,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vOTPMAILMESSAGEBODYHTML",fmt:0,gxz:"ZV74OTPMailMessageBodyHTML",gxold:"OV74OTPMailMessageBodyHTML",gxvar:"AV74OTPMailMessageBodyHTML",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV74OTPMailMessageBodyHTML=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV74OTPMailMessageBodyHTML=Value},v2c:function(){gx.fn.setControlValue("vOTPMAILMESSAGEBODYHTML",gx.O.AV74OTPMailMessageBodyHTML,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV74OTPMailMessageBodyHTML=this.val()},val:function(){return gx.fn.getControlValue("vOTPMAILMESSAGEBODYHTML")},nac:gx.falseFn};
   this.declareDomainHdlr( 157 , function() {
   });
   GXValidFnc[158]={ id: 158, fld:"",grid:0};
   GXValidFnc[159]={ id: 159, fld:"",grid:0};
   GXValidFnc[160]={ id: 160, fld:"",grid:0};
   GXValidFnc[161]={ id: 161, fld:"",grid:0};
   GXValidFnc[162]={ id:162 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vOTPEVENTVALIDATECODE",fmt:0,gxz:"ZV67OTPEventValidateCode",gxold:"OV67OTPEventValidateCode",gxvar:"AV67OTPEventValidateCode",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV67OTPEventValidateCode=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV67OTPEventValidateCode=Value},v2c:function(){gx.fn.setComboBoxValue("vOTPEVENTVALIDATECODE",gx.O.AV67OTPEventValidateCode);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV67OTPEventValidateCode=this.val()},val:function(){return gx.fn.getControlValue("vOTPEVENTVALIDATECODE")},nac:gx.falseFn};
   this.declareDomainHdlr( 162 , function() {
   });
   GXValidFnc[163]={ id: 163, fld:"",grid:0};
   GXValidFnc[164]={ id: 164, fld:"",grid:0};
   GXValidFnc[165]={ id: 165, fld:"TBLCLIENTIDSECRET",grid:0};
   GXValidFnc[166]={ id: 166, fld:"",grid:0};
   GXValidFnc[167]={ id: 167, fld:"",grid:0};
   GXValidFnc[168]={ id: 168, fld:"",grid:0};
   GXValidFnc[169]={ id: 169, fld:"",grid:0};
   GXValidFnc[170]={ id:170 ,lvl:0,type:"svchar",len:2048,dec:100,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTID",fmt:0,gxz:"ZV16ClientId",gxold:"OV16ClientId",gxvar:"AV16ClientId",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV16ClientId=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV16ClientId=Value},v2c:function(){gx.fn.setControlValue("vCLIENTID",gx.O.AV16ClientId,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV16ClientId=this.val()},val:function(){return gx.fn.getControlValue("vCLIENTID")},nac:gx.falseFn};
   this.declareDomainHdlr( 170 , function() {
   });
   GXValidFnc[171]={ id: 171, fld:"",grid:0};
   GXValidFnc[172]={ id: 172, fld:"",grid:0};
   GXValidFnc[173]={ id: 173, fld:"",grid:0};
   GXValidFnc[174]={ id: 174, fld:"",grid:0};
   GXValidFnc[175]={ id:175 ,lvl:0,type:"svchar",len:2048,dec:100,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTSECRET",fmt:0,gxz:"ZV17ClientSecret",gxold:"OV17ClientSecret",gxvar:"AV17ClientSecret",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV17ClientSecret=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV17ClientSecret=Value},v2c:function(){gx.fn.setControlValue("vCLIENTSECRET",gx.O.AV17ClientSecret,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV17ClientSecret=this.val()},val:function(){return gx.fn.getControlValue("vCLIENTSECRET")},nac:gx.falseFn};
   this.declareDomainHdlr( 175 , function() {
   });
   GXValidFnc[176]={ id: 176, fld:"",grid:0};
   GXValidFnc[177]={ id: 177, fld:"",grid:0};
   GXValidFnc[178]={ id: 178, fld:"",grid:0};
   GXValidFnc[179]={ id: 179, fld:"",grid:0};
   GXValidFnc[180]={ id:180 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vVERSIONPATH",fmt:0,gxz:"ZV52VersionPath",gxold:"OV52VersionPath",gxvar:"AV52VersionPath",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV52VersionPath=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV52VersionPath=Value},v2c:function(){gx.fn.setControlValue("vVERSIONPATH",gx.O.AV52VersionPath,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV52VersionPath=this.val()},val:function(){return gx.fn.getControlValue("vVERSIONPATH")},nac:gx.falseFn};
   this.declareDomainHdlr( 180 , function() {
   });
   GXValidFnc[181]={ id: 181, fld:"",grid:0};
   GXValidFnc[182]={ id: 182, fld:"",grid:0};
   GXValidFnc[183]={ id: 183, fld:"TBLCLIENTLOCALSERVER",grid:0};
   GXValidFnc[184]={ id: 184, fld:"",grid:0};
   GXValidFnc[185]={ id: 185, fld:"",grid:0};
   GXValidFnc[186]={ id: 186, fld:"",grid:0};
   GXValidFnc[187]={ id: 187, fld:"",grid:0};
   GXValidFnc[188]={ id:188 ,lvl:0,type:"svchar",len:2048,dec:250,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSITEURL",fmt:0,gxz:"ZV35SiteURL",gxold:"OV35SiteURL",gxvar:"AV35SiteURL",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV35SiteURL=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV35SiteURL=Value},v2c:function(){gx.fn.setControlValue("vSITEURL",gx.O.AV35SiteURL,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV35SiteURL=this.val()},val:function(){return gx.fn.getControlValue("vSITEURL")},nac:gx.falseFn};
   this.declareDomainHdlr( 188 , function() {
   });
   GXValidFnc[189]={ id: 189, fld:"",grid:0};
   GXValidFnc[190]={ id: 190, fld:"",grid:0};
   GXValidFnc[191]={ id: 191, fld:"",grid:0};
   GXValidFnc[192]={ id: 192, fld:"",grid:0};
   GXValidFnc[193]={ id:193 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vAUTOCOMPLETEVIRTUALDIRECTORY",fmt:0,gxz:"ZV85AutocompleteVirtualDirectory",gxold:"OV85AutocompleteVirtualDirectory",gxvar:"AV85AutocompleteVirtualDirectory",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV85AutocompleteVirtualDirectory=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV85AutocompleteVirtualDirectory=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vAUTOCOMPLETEVIRTUALDIRECTORY",gx.O.AV85AutocompleteVirtualDirectory,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV85AutocompleteVirtualDirectory=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vAUTOCOMPLETEVIRTUALDIRECTORY")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 193 , function() {
   });
   GXValidFnc[194]={ id: 194, fld:"",grid:0};
   GXValidFnc[195]={ id: 195, fld:"TBHELPAUTOCOMPLETEVIRTUALDIRECTORY", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[196]={ id: 196, fld:"",grid:0};
   GXValidFnc[197]={ id: 197, fld:"TBSPACE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[198]={ id: 198, fld:"",grid:0};
   GXValidFnc[199]={ id: 199, fld:"",grid:0};
   GXValidFnc[200]={ id: 200, fld:"TBLCUSTOMCALLBACKURL",grid:0};
   GXValidFnc[201]={ id: 201, fld:"",grid:0};
   GXValidFnc[202]={ id: 202, fld:"",grid:0};
   GXValidFnc[203]={ id: 203, fld:"",grid:0};
   GXValidFnc[204]={ id: 204, fld:"",grid:0};
   GXValidFnc[205]={ id:205 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSITEURLCALLBACKISCUSTOM",fmt:0,gxz:"ZV80SiteURLCallbackIsCustom",gxold:"OV80SiteURLCallbackIsCustom",gxvar:"AV80SiteURLCallbackIsCustom",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV80SiteURLCallbackIsCustom=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV80SiteURLCallbackIsCustom=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vSITEURLCALLBACKISCUSTOM",gx.O.AV80SiteURLCallbackIsCustom,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV80SiteURLCallbackIsCustom=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vSITEURLCALLBACKISCUSTOM")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 205 , function() {
   });
   GXValidFnc[206]={ id: 206, fld:"",grid:0};
   GXValidFnc[207]={ id: 207, fld:"",grid:0};
   GXValidFnc[208]={ id: 208, fld:"TBLTWITTER",grid:0};
   GXValidFnc[209]={ id: 209, fld:"",grid:0};
   GXValidFnc[210]={ id: 210, fld:"",grid:0};
   GXValidFnc[211]={ id: 211, fld:"",grid:0};
   GXValidFnc[212]={ id: 212, fld:"",grid:0};
   GXValidFnc[213]={ id:213 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCONSUMERKEY",fmt:0,gxz:"ZV18ConsumerKey",gxold:"OV18ConsumerKey",gxvar:"AV18ConsumerKey",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV18ConsumerKey=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV18ConsumerKey=Value},v2c:function(){gx.fn.setControlValue("vCONSUMERKEY",gx.O.AV18ConsumerKey,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV18ConsumerKey=this.val()},val:function(){return gx.fn.getControlValue("vCONSUMERKEY")},nac:gx.falseFn};
   GXValidFnc[214]={ id: 214, fld:"",grid:0};
   GXValidFnc[215]={ id: 215, fld:"",grid:0};
   GXValidFnc[216]={ id: 216, fld:"",grid:0};
   GXValidFnc[217]={ id: 217, fld:"",grid:0};
   GXValidFnc[218]={ id:218 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCONSUMERSECRET",fmt:0,gxz:"ZV19ConsumerSecret",gxold:"OV19ConsumerSecret",gxvar:"AV19ConsumerSecret",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV19ConsumerSecret=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV19ConsumerSecret=Value},v2c:function(){gx.fn.setControlValue("vCONSUMERSECRET",gx.O.AV19ConsumerSecret,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV19ConsumerSecret=this.val()},val:function(){return gx.fn.getControlValue("vCONSUMERSECRET")},nac:gx.falseFn};
   GXValidFnc[219]={ id: 219, fld:"",grid:0};
   GXValidFnc[220]={ id: 220, fld:"",grid:0};
   GXValidFnc[221]={ id: 221, fld:"",grid:0};
   GXValidFnc[222]={ id: 222, fld:"",grid:0};
   GXValidFnc[223]={ id:223 ,lvl:0,type:"svchar",len:2048,dec:250,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCALLBACKURL",fmt:0,gxz:"ZV15CallbackURL",gxold:"OV15CallbackURL",gxvar:"AV15CallbackURL",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV15CallbackURL=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV15CallbackURL=Value},v2c:function(){gx.fn.setControlValue("vCALLBACKURL",gx.O.AV15CallbackURL,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV15CallbackURL=this.val()},val:function(){return gx.fn.getControlValue("vCALLBACKURL")},nac:gx.falseFn};
   this.declareDomainHdlr( 223 , function() {
   });
   GXValidFnc[224]={ id: 224, fld:"",grid:0};
   GXValidFnc[225]={ id: 225, fld:"",grid:0};
   GXValidFnc[226]={ id: 226, fld:"",grid:0};
   GXValidFnc[227]={ id: 227, fld:"",grid:0};
   GXValidFnc[228]={ id:228 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCUAUTOCOMPLETEVIRTUALDIRECTORY",fmt:0,gxz:"ZV86CUAutocompleteVirtualDirectory",gxold:"OV86CUAutocompleteVirtualDirectory",gxvar:"AV86CUAutocompleteVirtualDirectory",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV86CUAutocompleteVirtualDirectory=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV86CUAutocompleteVirtualDirectory=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCUAUTOCOMPLETEVIRTUALDIRECTORY",gx.O.AV86CUAutocompleteVirtualDirectory,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV86CUAutocompleteVirtualDirectory=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCUAUTOCOMPLETEVIRTUALDIRECTORY")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 228 , function() {
   });
   GXValidFnc[229]={ id: 229, fld:"",grid:0};
   GXValidFnc[230]={ id: 230, fld:"TBHELPCUAUTOCOMPLETEVIRTUALDIRECTORY", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[231]={ id: 231, fld:"",grid:0};
   GXValidFnc[232]={ id: 232, fld:"TBSPACE2", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[233]={ id: 233, fld:"",grid:0};
   GXValidFnc[234]={ id: 234, fld:"",grid:0};
   GXValidFnc[235]={ id: 235, fld:"TBLSCOPES",grid:0};
   GXValidFnc[236]={ id: 236, fld:"",grid:0};
   GXValidFnc[237]={ id: 237, fld:"",grid:0};
   GXValidFnc[238]={ id: 238, fld:"",grid:0};
   GXValidFnc[239]={ id: 239, fld:"",grid:0};
   GXValidFnc[240]={ id:240 ,lvl:0,type:"boolean",len:4,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vADDUSERADDITIONALDATASCOPE",fmt:0,gxz:"ZV54AddUserAdditionalDataScope",gxold:"OV54AddUserAdditionalDataScope",gxvar:"AV54AddUserAdditionalDataScope",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV54AddUserAdditionalDataScope=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV54AddUserAdditionalDataScope=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vADDUSERADDITIONALDATASCOPE",gx.O.AV54AddUserAdditionalDataScope,true)},c2v:function(){if(this.val()!==undefined)gx.O.AV54AddUserAdditionalDataScope=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vADDUSERADDITIONALDATASCOPE")},nac:gx.falseFn,values:['true','false']};
   GXValidFnc[241]={ id: 241, fld:"",grid:0};
   GXValidFnc[242]={ id: 242, fld:"",grid:0};
   GXValidFnc[243]={ id: 243, fld:"",grid:0};
   GXValidFnc[244]={ id:244 ,lvl:0,type:"boolean",len:4,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vADDINITIALPROPERTIESSCOPE",fmt:0,gxz:"ZV50AddInitialPropertiesScope",gxold:"OV50AddInitialPropertiesScope",gxvar:"AV50AddInitialPropertiesScope",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV50AddInitialPropertiesScope=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV50AddInitialPropertiesScope=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vADDINITIALPROPERTIESSCOPE",gx.O.AV50AddInitialPropertiesScope,true)},c2v:function(){if(this.val()!==undefined)gx.O.AV50AddInitialPropertiesScope=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vADDINITIALPROPERTIESSCOPE")},nac:gx.falseFn,values:['true','false']};
   GXValidFnc[245]={ id: 245, fld:"",grid:0};
   GXValidFnc[246]={ id: 246, fld:"",grid:0};
   GXValidFnc[247]={ id: 247, fld:"TBLCOMMONADDITIONAL",grid:0};
   GXValidFnc[248]={ id: 248, fld:"",grid:0};
   GXValidFnc[249]={ id: 249, fld:"",grid:0};
   GXValidFnc[250]={ id: 250, fld:"",grid:0};
   GXValidFnc[251]={ id: 251, fld:"",grid:0};
   GXValidFnc[252]={ id:252 ,lvl:0,type:"svchar",len:2048,dec:250,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vADDITIONALSCOPE",fmt:0,gxz:"ZV5AdditionalScope",gxold:"OV5AdditionalScope",gxvar:"AV5AdditionalScope",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV5AdditionalScope=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV5AdditionalScope=Value},v2c:function(){gx.fn.setControlValue("vADDITIONALSCOPE",gx.O.AV5AdditionalScope,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV5AdditionalScope=this.val()},val:function(){return gx.fn.getControlValue("vADDITIONALSCOPE")},nac:gx.falseFn};
   this.declareDomainHdlr( 252 , function() {
   });
   GXValidFnc[253]={ id: 253, fld:"",grid:0};
   GXValidFnc[254]={ id: 254, fld:"",grid:0};
   GXValidFnc[255]={ id: 255, fld:"TBLAUTHTYPENAME",grid:0};
   GXValidFnc[256]={ id: 256, fld:"",grid:0};
   GXValidFnc[257]={ id: 257, fld:"",grid:0};
   GXValidFnc[258]={ id: 258, fld:"",grid:0};
   GXValidFnc[259]={ id: 259, fld:"",grid:0};
   GXValidFnc[260]={ id:260 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGAMRAUTHENTICATIONTYPENAME",fmt:0,gxz:"ZV53GAMRAuthenticationTypeName",gxold:"OV53GAMRAuthenticationTypeName",gxvar:"AV53GAMRAuthenticationTypeName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV53GAMRAuthenticationTypeName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV53GAMRAuthenticationTypeName=Value},v2c:function(){gx.fn.setControlValue("vGAMRAUTHENTICATIONTYPENAME",gx.O.AV53GAMRAuthenticationTypeName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV53GAMRAuthenticationTypeName=this.val()},val:function(){return gx.fn.getControlValue("vGAMRAUTHENTICATIONTYPENAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 260 , function() {
   });
   GXValidFnc[261]={ id: 261, fld:"",grid:0};
   GXValidFnc[262]={ id: 262, fld:"",grid:0};
   GXValidFnc[263]={ id: 263, fld:"TBLSERVERHOST",grid:0};
   GXValidFnc[264]={ id: 264, fld:"",grid:0};
   GXValidFnc[265]={ id: 265, fld:"",grid:0};
   GXValidFnc[266]={ id: 266, fld:"",grid:0};
   GXValidFnc[267]={ id: 267, fld:"",grid:0};
   GXValidFnc[268]={ id:268 ,lvl:0,type:"svchar",len:2048,dec:250,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGAMRSERVERURL",fmt:0,gxz:"ZV31GAMRServerURL",gxold:"OV31GAMRServerURL",gxvar:"AV31GAMRServerURL",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV31GAMRServerURL=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV31GAMRServerURL=Value},v2c:function(){gx.fn.setControlValue("vGAMRSERVERURL",gx.O.AV31GAMRServerURL,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV31GAMRServerURL=this.val()},val:function(){return gx.fn.getControlValue("vGAMRSERVERURL")},nac:gx.falseFn};
   this.declareDomainHdlr( 268 , function() {
   });
   GXValidFnc[269]={ id: 269, fld:"",grid:0};
   GXValidFnc[270]={ id: 270, fld:"",grid:0};
   GXValidFnc[271]={ id: 271, fld:"",grid:0};
   GXValidFnc[272]={ id: 272, fld:"",grid:0};
   GXValidFnc[273]={ id:273 ,lvl:0,type:"char",len:32,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGAMRPRIVATEENCRYPTKEY",fmt:0,gxz:"ZV29GAMRPrivateEncryptKey",gxold:"OV29GAMRPrivateEncryptKey",gxvar:"AV29GAMRPrivateEncryptKey",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV29GAMRPrivateEncryptKey=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV29GAMRPrivateEncryptKey=Value},v2c:function(){gx.fn.setControlValue("vGAMRPRIVATEENCRYPTKEY",gx.O.AV29GAMRPrivateEncryptKey,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV29GAMRPrivateEncryptKey=this.val()},val:function(){return gx.fn.getControlValue("vGAMRPRIVATEENCRYPTKEY")},nac:gx.falseFn};
   this.declareDomainHdlr( 273 , function() {
   });
   GXValidFnc[274]={ id: 274, fld:"",grid:0};
   GXValidFnc[275]={ id: 275, fld:"FORMCELL",grid:0};
   GXValidFnc[276]={ id: 276, fld:"",grid:0};
   GXValidFnc[277]={ id: 277, fld:"",grid:0};
   GXValidFnc[278]={ id:278 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGAMRREPOSITORYGUID",fmt:0,gxz:"ZV30GAMRRepositoryGUID",gxold:"OV30GAMRRepositoryGUID",gxvar:"AV30GAMRRepositoryGUID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV30GAMRRepositoryGUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV30GAMRRepositoryGUID=Value},v2c:function(){gx.fn.setControlValue("vGAMRREPOSITORYGUID",gx.O.AV30GAMRRepositoryGUID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV30GAMRRepositoryGUID=this.val()},val:function(){return gx.fn.getControlValue("vGAMRREPOSITORYGUID")},nac:gx.falseFn};
   this.declareDomainHdlr( 278 , function() {
   });
   GXValidFnc[279]={ id: 279, fld:"",grid:0};
   GXValidFnc[280]={ id: 280, fld:"",grid:0};
   GXValidFnc[281]={ id: 281, fld:"",grid:0};
   GXValidFnc[282]={ id: 282, fld:"",grid:0};
   GXValidFnc[283]={ id:283 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vAUTOVALIDATEEXTERNALTOKENANDREFRESH",fmt:0,gxz:"ZV57AutovalidateExternalTokenAndRefresh",gxold:"OV57AutovalidateExternalTokenAndRefresh",gxvar:"AV57AutovalidateExternalTokenAndRefresh",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV57AutovalidateExternalTokenAndRefresh=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV57AutovalidateExternalTokenAndRefresh=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vAUTOVALIDATEEXTERNALTOKENANDREFRESH",gx.O.AV57AutovalidateExternalTokenAndRefresh,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV57AutovalidateExternalTokenAndRefresh=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vAUTOVALIDATEEXTERNALTOKENANDREFRESH")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 283 , function() {
   });
   GXValidFnc[284]={ id: 284, fld:"",grid:0};
   GXValidFnc[285]={ id: 285, fld:"",grid:0};
   GXValidFnc[286]={ id: 286, fld:"TBLWEBSERVICE",grid:0};
   GXValidFnc[287]={ id: 287, fld:"",grid:0};
   GXValidFnc[288]={ id: 288, fld:"",grid:0};
   GXValidFnc[289]={ id: 289, fld:"",grid:0};
   GXValidFnc[290]={ id: 290, fld:"",grid:0};
   GXValidFnc[291]={ id:291 ,lvl:0,type:"char",len:20,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Wsversion,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vWSVERSION",fmt:0,gxz:"ZV47WSVersion",gxold:"OV47WSVersion",gxvar:"AV47WSVersion",ucs:[],op:[291],ip:[291],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV47WSVersion=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV47WSVersion=Value},v2c:function(){gx.fn.setComboBoxValue("vWSVERSION",gx.O.AV47WSVersion);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV47WSVersion=this.val()},val:function(){return gx.fn.getControlValue("vWSVERSION")},nac:gx.falseFn};
   this.declareDomainHdlr( 291 , function() {
   });
   GXValidFnc[292]={ id: 292, fld:"",grid:0};
   GXValidFnc[293]={ id: 293, fld:"",grid:0};
   GXValidFnc[294]={ id: 294, fld:"",grid:0};
   GXValidFnc[295]={ id: 295, fld:"",grid:0};
   GXValidFnc[296]={ id:296 ,lvl:0,type:"char",len:32,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vWSPRIVATEENCRYPTKEY",fmt:0,gxz:"ZV41WSPrivateEncryptKey",gxold:"OV41WSPrivateEncryptKey",gxvar:"AV41WSPrivateEncryptKey",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV41WSPrivateEncryptKey=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV41WSPrivateEncryptKey=Value},v2c:function(){gx.fn.setControlValue("vWSPRIVATEENCRYPTKEY",gx.O.AV41WSPrivateEncryptKey,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV41WSPrivateEncryptKey=this.val()},val:function(){return gx.fn.getControlValue("vWSPRIVATEENCRYPTKEY")},nac:gx.falseFn};
   this.declareDomainHdlr( 296 , function() {
   });
   GXValidFnc[297]={ id: 297, fld:"",grid:0};
   GXValidFnc[298]={ id: 298, fld:"BTNGENKEY",grid:0,evt:"e132q2_client"};
   GXValidFnc[299]={ id: 299, fld:"",grid:0};
   GXValidFnc[300]={ id: 300, fld:"",grid:0};
   GXValidFnc[301]={ id: 301, fld:"",grid:0};
   GXValidFnc[302]={ id: 302, fld:"",grid:0};
   GXValidFnc[303]={ id:303 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vWSSERVERNAME",fmt:0,gxz:"ZV43WSServerName",gxold:"OV43WSServerName",gxvar:"AV43WSServerName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV43WSServerName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV43WSServerName=Value},v2c:function(){gx.fn.setControlValue("vWSSERVERNAME",gx.O.AV43WSServerName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV43WSServerName=this.val()},val:function(){return gx.fn.getControlValue("vWSSERVERNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 303 , function() {
   });
   GXValidFnc[304]={ id: 304, fld:"",grid:0};
   GXValidFnc[305]={ id: 305, fld:"",grid:0};
   GXValidFnc[306]={ id: 306, fld:"",grid:0};
   GXValidFnc[307]={ id: 307, fld:"",grid:0};
   GXValidFnc[308]={ id:308 ,lvl:0,type:"int",len:5,dec:0,sign:false,pic:"ZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vWSSERVERPORT",fmt:0,gxz:"ZV44WSServerPort",gxold:"OV44WSServerPort",gxvar:"AV44WSServerPort",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV44WSServerPort=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV44WSServerPort=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vWSSERVERPORT",gx.O.AV44WSServerPort,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV44WSServerPort=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vWSSERVERPORT",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[309]={ id: 309, fld:"",grid:0};
   GXValidFnc[310]={ id: 310, fld:"",grid:0};
   GXValidFnc[311]={ id: 311, fld:"",grid:0};
   GXValidFnc[312]={ id: 312, fld:"",grid:0};
   GXValidFnc[313]={ id:313 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vWSSERVERBASEURL",fmt:0,gxz:"ZV42WSServerBaseURL",gxold:"OV42WSServerBaseURL",gxvar:"AV42WSServerBaseURL",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV42WSServerBaseURL=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV42WSServerBaseURL=Value},v2c:function(){gx.fn.setControlValue("vWSSERVERBASEURL",gx.O.AV42WSServerBaseURL,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV42WSServerBaseURL=this.val()},val:function(){return gx.fn.getControlValue("vWSSERVERBASEURL")},nac:gx.falseFn};
   this.declareDomainHdlr( 313 , function() {
   });
   GXValidFnc[314]={ id: 314, fld:"",grid:0};
   GXValidFnc[315]={ id: 315, fld:"",grid:0};
   GXValidFnc[316]={ id: 316, fld:"",grid:0};
   GXValidFnc[317]={ id: 317, fld:"",grid:0};
   GXValidFnc[318]={ id:318 ,lvl:0,type:"int",len:1,dec:0,sign:false,pic:"9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vWSSERVERSECUREPROTOCOL",fmt:0,gxz:"ZV45WSServerSecureProtocol",gxold:"OV45WSServerSecureProtocol",gxvar:"AV45WSServerSecureProtocol",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV45WSServerSecureProtocol=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV45WSServerSecureProtocol=gx.num.intval(Value)},v2c:function(){gx.fn.setComboBoxValue("vWSSERVERSECUREPROTOCOL",gx.O.AV45WSServerSecureProtocol)},c2v:function(){if(this.val()!==undefined)gx.O.AV45WSServerSecureProtocol=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vWSSERVERSECUREPROTOCOL",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[319]={ id: 319, fld:"",grid:0};
   GXValidFnc[320]={ id: 320, fld:"",grid:0};
   GXValidFnc[321]={ id: 321, fld:"",grid:0};
   GXValidFnc[322]={ id: 322, fld:"",grid:0};
   GXValidFnc[323]={ id:323 ,lvl:0,type:"int",len:5,dec:0,sign:false,pic:"ZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vWSTIMEOUT",fmt:0,gxz:"ZV46WSTimeout",gxold:"OV46WSTimeout",gxvar:"AV46WSTimeout",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV46WSTimeout=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV46WSTimeout=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vWSTIMEOUT",gx.O.AV46WSTimeout,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV46WSTimeout=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vWSTIMEOUT",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[324]={ id: 324, fld:"",grid:0};
   GXValidFnc[325]={ id: 325, fld:"",grid:0};
   GXValidFnc[326]={ id: 326, fld:"",grid:0};
   GXValidFnc[327]={ id: 327, fld:"",grid:0};
   GXValidFnc[328]={ id:328 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vWSPACKAGE",fmt:0,gxz:"ZV40WSPackage",gxold:"OV40WSPackage",gxvar:"AV40WSPackage",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV40WSPackage=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV40WSPackage=Value},v2c:function(){gx.fn.setControlValue("vWSPACKAGE",gx.O.AV40WSPackage,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV40WSPackage=this.val()},val:function(){return gx.fn.getControlValue("vWSPACKAGE")},nac:gx.falseFn};
   this.declareDomainHdlr( 328 , function() {
   });
   GXValidFnc[329]={ id: 329, fld:"",grid:0};
   GXValidFnc[330]={ id: 330, fld:"",grid:0};
   GXValidFnc[331]={ id: 331, fld:"",grid:0};
   GXValidFnc[332]={ id: 332, fld:"",grid:0};
   GXValidFnc[333]={ id:333 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vWSNAME",fmt:0,gxz:"ZV39WSName",gxold:"OV39WSName",gxvar:"AV39WSName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV39WSName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV39WSName=Value},v2c:function(){gx.fn.setControlValue("vWSNAME",gx.O.AV39WSName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV39WSName=this.val()},val:function(){return gx.fn.getControlValue("vWSNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 333 , function() {
   });
   GXValidFnc[334]={ id: 334, fld:"",grid:0};
   GXValidFnc[335]={ id: 335, fld:"",grid:0};
   GXValidFnc[336]={ id: 336, fld:"",grid:0};
   GXValidFnc[337]={ id: 337, fld:"",grid:0};
   GXValidFnc[338]={ id:338 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vWSEXTENSION",fmt:0,gxz:"ZV38WSExtension",gxold:"OV38WSExtension",gxvar:"AV38WSExtension",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV38WSExtension=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV38WSExtension=Value},v2c:function(){gx.fn.setControlValue("vWSEXTENSION",gx.O.AV38WSExtension,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV38WSExtension=this.val()},val:function(){return gx.fn.getControlValue("vWSEXTENSION")},nac:gx.falseFn};
   this.declareDomainHdlr( 338 , function() {
   });
   GXValidFnc[339]={ id: 339, fld:"",grid:0};
   GXValidFnc[340]={ id: 340, fld:"",grid:0};
   GXValidFnc[341]={ id: 341, fld:"TBLEXTERNAL",grid:0};
   GXValidFnc[342]={ id: 342, fld:"",grid:0};
   GXValidFnc[343]={ id: 343, fld:"",grid:0};
   GXValidFnc[344]={ id: 344, fld:"",grid:0};
   GXValidFnc[345]={ id: 345, fld:"",grid:0};
   GXValidFnc[346]={ id:346 ,lvl:0,type:"char",len:20,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Cusversion,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCUSVERSION",fmt:0,gxz:"ZV24CusVersion",gxold:"OV24CusVersion",gxvar:"AV24CusVersion",ucs:[],op:[346],ip:[346],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV24CusVersion=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV24CusVersion=Value},v2c:function(){gx.fn.setComboBoxValue("vCUSVERSION",gx.O.AV24CusVersion);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV24CusVersion=this.val()},val:function(){return gx.fn.getControlValue("vCUSVERSION")},nac:gx.falseFn};
   this.declareDomainHdlr( 346 , function() {
   });
   GXValidFnc[347]={ id: 347, fld:"",grid:0};
   GXValidFnc[348]={ id: 348, fld:"",grid:0};
   GXValidFnc[349]={ id: 349, fld:"",grid:0};
   GXValidFnc[350]={ id: 350, fld:"",grid:0};
   GXValidFnc[351]={ id:351 ,lvl:0,type:"char",len:32,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCUSPRIVATEENCRYPTKEY",fmt:0,gxz:"ZV23CusPrivateEncryptKey",gxold:"OV23CusPrivateEncryptKey",gxvar:"AV23CusPrivateEncryptKey",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV23CusPrivateEncryptKey=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV23CusPrivateEncryptKey=Value},v2c:function(){gx.fn.setControlValue("vCUSPRIVATEENCRYPTKEY",gx.O.AV23CusPrivateEncryptKey,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV23CusPrivateEncryptKey=this.val()},val:function(){return gx.fn.getControlValue("vCUSPRIVATEENCRYPTKEY")},nac:gx.falseFn};
   this.declareDomainHdlr( 351 , function() {
   });
   GXValidFnc[352]={ id: 352, fld:"",grid:0};
   GXValidFnc[353]={ id: 353, fld:"BTNGENKEYCUSTOM",grid:0,evt:"e142q2_client"};
   GXValidFnc[354]={ id: 354, fld:"",grid:0};
   GXValidFnc[355]={ id: 355, fld:"",grid:0};
   GXValidFnc[356]={ id: 356, fld:"",grid:0};
   GXValidFnc[357]={ id: 357, fld:"",grid:0};
   GXValidFnc[358]={ id:358 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCUSFILENAME",fmt:0,gxz:"ZV21CusFileName",gxold:"OV21CusFileName",gxvar:"AV21CusFileName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV21CusFileName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV21CusFileName=Value},v2c:function(){gx.fn.setControlValue("vCUSFILENAME",gx.O.AV21CusFileName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV21CusFileName=this.val()},val:function(){return gx.fn.getControlValue("vCUSFILENAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 358 , function() {
   });
   GXValidFnc[359]={ id: 359, fld:"",grid:0};
   GXValidFnc[360]={ id: 360, fld:"",grid:0};
   GXValidFnc[361]={ id: 361, fld:"",grid:0};
   GXValidFnc[362]={ id: 362, fld:"",grid:0};
   GXValidFnc[363]={ id:363 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCUSPACKAGE",fmt:0,gxz:"ZV22CusPackage",gxold:"OV22CusPackage",gxvar:"AV22CusPackage",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV22CusPackage=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV22CusPackage=Value},v2c:function(){gx.fn.setControlValue("vCUSPACKAGE",gx.O.AV22CusPackage,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV22CusPackage=this.val()},val:function(){return gx.fn.getControlValue("vCUSPACKAGE")},nac:gx.falseFn};
   this.declareDomainHdlr( 363 , function() {
   });
   GXValidFnc[364]={ id: 364, fld:"",grid:0};
   GXValidFnc[365]={ id: 365, fld:"",grid:0};
   GXValidFnc[366]={ id: 366, fld:"",grid:0};
   GXValidFnc[367]={ id: 367, fld:"",grid:0};
   GXValidFnc[368]={ id:368 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCUSCLASSNAME",fmt:0,gxz:"ZV20CusClassName",gxold:"OV20CusClassName",gxvar:"AV20CusClassName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV20CusClassName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV20CusClassName=Value},v2c:function(){gx.fn.setControlValue("vCUSCLASSNAME",gx.O.AV20CusClassName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV20CusClassName=this.val()},val:function(){return gx.fn.getControlValue("vCUSCLASSNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 368 , function() {
   });
   GXValidFnc[369]={ id: 369, fld:"",grid:0};
   GXValidFnc[370]={ id: 370, fld:"",grid:0};
   GXValidFnc[371]={ id: 371, fld:"",grid:0};
   GXValidFnc[372]={ id: 372, fld:"",grid:0};
   GXValidFnc[373]={ id:373 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCUSMETHOD",fmt:0,gxz:"ZV87CusMethod",gxold:"OV87CusMethod",gxvar:"AV87CusMethod",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV87CusMethod=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV87CusMethod=Value},v2c:function(){gx.fn.setControlValue("vCUSMETHOD",gx.O.AV87CusMethod,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV87CusMethod=this.val()},val:function(){return gx.fn.getControlValue("vCUSMETHOD")},nac:gx.falseFn};
   this.declareDomainHdlr( 373 , function() {
   });
   GXValidFnc[374]={ id: 374, fld:"",grid:0};
   GXValidFnc[375]={ id: 375, fld:"",grid:0};
   GXValidFnc[376]={ id: 376, fld:"TBLENABLETWOFACTORAUTH",grid:0};
   GXValidFnc[377]={ id: 377, fld:"",grid:0};
   GXValidFnc[378]={ id: 378, fld:"",grid:0};
   GXValidFnc[379]={ id: 379, fld:"",grid:0};
   GXValidFnc[380]={ id: 380, fld:"",grid:0};
   GXValidFnc[381]={ id:381 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vTFAENABLE",fmt:0,gxz:"ZV82TFAEnable",gxold:"OV82TFAEnable",gxvar:"AV82TFAEnable",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV82TFAEnable=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV82TFAEnable=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vTFAENABLE",gx.O.AV82TFAEnable,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV82TFAEnable=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vTFAENABLE")},nac:gx.falseFn,evt:"e152q2_client",values:['true','false']};
   this.declareDomainHdlr( 381 , function() {
   });
   GXValidFnc[382]={ id: 382, fld:"",grid:0};
   GXValidFnc[383]={ id: 383, fld:"",grid:0};
   GXValidFnc[384]={ id: 384, fld:"TBLTWOFACTORAUTHENTICATION",grid:0};
   GXValidFnc[385]={ id: 385, fld:"",grid:0};
   GXValidFnc[386]={ id: 386, fld:"",grid:0};
   GXValidFnc[387]={ id: 387, fld:"",grid:0};
   GXValidFnc[388]={ id: 388, fld:"",grid:0};
   GXValidFnc[389]={ id:389 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vTFAAUTHENTICATIONTYPENAME",fmt:0,gxz:"ZV81TFAAuthenticationTypeName",gxold:"OV81TFAAuthenticationTypeName",gxvar:"AV81TFAAuthenticationTypeName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV81TFAAuthenticationTypeName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV81TFAAuthenticationTypeName=Value},v2c:function(){gx.fn.setComboBoxValue("vTFAAUTHENTICATIONTYPENAME",gx.O.AV81TFAAuthenticationTypeName);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV81TFAAuthenticationTypeName=this.val()},val:function(){return gx.fn.getControlValue("vTFAAUTHENTICATIONTYPENAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 389 , function() {
   });
   GXValidFnc[390]={ id: 390, fld:"",grid:0};
   GXValidFnc[391]={ id: 391, fld:"",grid:0};
   GXValidFnc[392]={ id: 392, fld:"",grid:0};
   GXValidFnc[393]={ id: 393, fld:"",grid:0};
   GXValidFnc[394]={ id:394 ,lvl:0,type:"int",len:9,dec:0,sign:false,pic:"ZZZZZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vTFAFIRSTFACTORAUTHENTICATIONEXPIRATION",fmt:0,gxz:"ZV83TFAFirstFactorAuthenticationExpiration",gxold:"OV83TFAFirstFactorAuthenticationExpiration",gxvar:"AV83TFAFirstFactorAuthenticationExpiration",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV83TFAFirstFactorAuthenticationExpiration=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV83TFAFirstFactorAuthenticationExpiration=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vTFAFIRSTFACTORAUTHENTICATIONEXPIRATION",gx.O.AV83TFAFirstFactorAuthenticationExpiration,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV83TFAFirstFactorAuthenticationExpiration=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vTFAFIRSTFACTORAUTHENTICATIONEXPIRATION",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[395]={ id: 395, fld:"",grid:0};
   GXValidFnc[396]={ id: 396, fld:"",grid:0};
   GXValidFnc[397]={ id: 397, fld:"",grid:0};
   GXValidFnc[398]={ id: 398, fld:"",grid:0};
   GXValidFnc[399]={ id:399 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vTFAFORCEFORALLUSERS",fmt:0,gxz:"ZV84TFAForceForAllUsers",gxold:"OV84TFAForceForAllUsers",gxvar:"AV84TFAForceForAllUsers",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV84TFAForceForAllUsers=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV84TFAForceForAllUsers=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vTFAFORCEFORALLUSERS",gx.O.AV84TFAForceForAllUsers,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV84TFAForceForAllUsers=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vTFAFORCEFORALLUSERS")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 399 , function() {
   });
   GXValidFnc[400]={ id: 400, fld:"",grid:0};
   GXValidFnc[401]={ id: 401, fld:"",grid:0};
   GXValidFnc[403]={ id: 403, fld:"",grid:0};
   GXValidFnc[404]={ id: 404, fld:"",grid:0};
   GXValidFnc[405]={ id: 405, fld:"GAM_FOOTERENTRY",grid:0};
   GXValidFnc[406]={ id: 406, fld:"",grid:0};
   GXValidFnc[407]={ id: 407, fld:"",grid:0};
   GXValidFnc[408]={ id: 408, fld:"GAM_FOOTERENTRY_TABLEBUTTONS",grid:0};
   GXValidFnc[409]={ id: 409, fld:"",grid:0};
   GXValidFnc[410]={ id: 410, fld:"GAM_FOOTERENTRY_BTNCANCEL",grid:0,evt:"e172q2_client"};
   GXValidFnc[411]={ id: 411, fld:"",grid:0};
   GXValidFnc[412]={ id: 412, fld:"GAM_FOOTERENTRY_BTNCONFIRM",grid:0,evt:"e122q2_client"};
   this.AV37TypeId = "" ;
   this.ZV37TypeId = "" ;
   this.OV37TypeId = "" ;
   this.AV34Name = "" ;
   this.ZV34Name = "" ;
   this.OV34Name = "" ;
   this.AV28FunctionId = "" ;
   this.ZV28FunctionId = "" ;
   this.OV28FunctionId = "" ;
   this.AV33IsEnable = false ;
   this.ZV33IsEnable = false ;
   this.OV33IsEnable = false ;
   this.AV25Dsc = "" ;
   this.ZV25Dsc = "" ;
   this.OV25Dsc = "" ;
   this.AV36SmallImageName = "" ;
   this.ZV36SmallImageName = "" ;
   this.OV36SmallImageName = "" ;
   this.AV14BigImageName = "" ;
   this.ZV14BigImageName = "" ;
   this.OV14BigImageName = "" ;
   this.AV32Impersonate = "" ;
   this.ZV32Impersonate = "" ;
   this.OV32Impersonate = "" ;
   this.AV79OTPUseForFirstFactorAuthentication = false ;
   this.ZV79OTPUseForFirstFactorAuthentication = false ;
   this.OV79OTPUseForFirstFactorAuthentication = false ;
   this.AV68OTPEventValidateUser = "" ;
   this.ZV68OTPEventValidateUser = "" ;
   this.OV68OTPEventValidateUser = "" ;
   this.AV70OTPGenerationType = "" ;
   this.ZV70OTPGenerationType = "" ;
   this.OV70OTPGenerationType = "" ;
   this.AV71OTPGenerationType_CustomEventGenerateCode = "" ;
   this.ZV71OTPGenerationType_CustomEventGenerateCode = "" ;
   this.OV71OTPGenerationType_CustomEventGenerateCode = "" ;
   this.AV63OTPAutogeneratedCodeLength = 0 ;
   this.ZV63OTPAutogeneratedCodeLength = 0 ;
   this.OV63OTPAutogeneratedCodeLength = 0 ;
   this.AV69OTPGenerateCodeOnlyNumbers = false ;
   this.ZV69OTPGenerateCodeOnlyNumbers = false ;
   this.OV69OTPGenerateCodeOnlyNumbers = false ;
   this.AV65OTPCodeExpirationTimeout = 0 ;
   this.ZV65OTPCodeExpirationTimeout = 0 ;
   this.OV65OTPCodeExpirationTimeout = 0 ;
   this.AV76OTPMaximumDailyNumberCodes = 0 ;
   this.ZV76OTPMaximumDailyNumberCodes = 0 ;
   this.OV76OTPMaximumDailyNumberCodes = 0 ;
   this.AV78OTPNumberUnsuccessfulRetriesToLockOTP = 0 ;
   this.ZV78OTPNumberUnsuccessfulRetriesToLockOTP = 0 ;
   this.OV78OTPNumberUnsuccessfulRetriesToLockOTP = 0 ;
   this.AV64OTPAutoUnlockTime = 0 ;
   this.ZV64OTPAutoUnlockTime = 0 ;
   this.OV64OTPAutoUnlockTime = 0 ;
   this.AV77OTPNumberUnsuccessfulRetriesToBlockUserBasedOfOTPLocks = 0 ;
   this.ZV77OTPNumberUnsuccessfulRetriesToBlockUserBasedOfOTPLocks = 0 ;
   this.OV77OTPNumberUnsuccessfulRetriesToBlockUserBasedOfOTPLocks = 0 ;
   this.AV66OTPEventSendCode = "" ;
   this.ZV66OTPEventSendCode = "" ;
   this.OV66OTPEventSendCode = "" ;
   this.AV75OTPMailMessageSubject = "" ;
   this.ZV75OTPMailMessageSubject = "" ;
   this.OV75OTPMailMessageSubject = "" ;
   this.AV74OTPMailMessageBodyHTML = "" ;
   this.ZV74OTPMailMessageBodyHTML = "" ;
   this.OV74OTPMailMessageBodyHTML = "" ;
   this.AV67OTPEventValidateCode = "" ;
   this.ZV67OTPEventValidateCode = "" ;
   this.OV67OTPEventValidateCode = "" ;
   this.AV16ClientId = "" ;
   this.ZV16ClientId = "" ;
   this.OV16ClientId = "" ;
   this.AV17ClientSecret = "" ;
   this.ZV17ClientSecret = "" ;
   this.OV17ClientSecret = "" ;
   this.AV52VersionPath = "" ;
   this.ZV52VersionPath = "" ;
   this.OV52VersionPath = "" ;
   this.AV35SiteURL = "" ;
   this.ZV35SiteURL = "" ;
   this.OV35SiteURL = "" ;
   this.AV85AutocompleteVirtualDirectory = false ;
   this.ZV85AutocompleteVirtualDirectory = false ;
   this.OV85AutocompleteVirtualDirectory = false ;
   this.AV80SiteURLCallbackIsCustom = false ;
   this.ZV80SiteURLCallbackIsCustom = false ;
   this.OV80SiteURLCallbackIsCustom = false ;
   this.AV18ConsumerKey = "" ;
   this.ZV18ConsumerKey = "" ;
   this.OV18ConsumerKey = "" ;
   this.AV19ConsumerSecret = "" ;
   this.ZV19ConsumerSecret = "" ;
   this.OV19ConsumerSecret = "" ;
   this.AV15CallbackURL = "" ;
   this.ZV15CallbackURL = "" ;
   this.OV15CallbackURL = "" ;
   this.AV86CUAutocompleteVirtualDirectory = false ;
   this.ZV86CUAutocompleteVirtualDirectory = false ;
   this.OV86CUAutocompleteVirtualDirectory = false ;
   this.AV54AddUserAdditionalDataScope = false ;
   this.ZV54AddUserAdditionalDataScope = false ;
   this.OV54AddUserAdditionalDataScope = false ;
   this.AV50AddInitialPropertiesScope = false ;
   this.ZV50AddInitialPropertiesScope = false ;
   this.OV50AddInitialPropertiesScope = false ;
   this.AV5AdditionalScope = "" ;
   this.ZV5AdditionalScope = "" ;
   this.OV5AdditionalScope = "" ;
   this.AV53GAMRAuthenticationTypeName = "" ;
   this.ZV53GAMRAuthenticationTypeName = "" ;
   this.OV53GAMRAuthenticationTypeName = "" ;
   this.AV31GAMRServerURL = "" ;
   this.ZV31GAMRServerURL = "" ;
   this.OV31GAMRServerURL = "" ;
   this.AV29GAMRPrivateEncryptKey = "" ;
   this.ZV29GAMRPrivateEncryptKey = "" ;
   this.OV29GAMRPrivateEncryptKey = "" ;
   this.AV30GAMRRepositoryGUID = "" ;
   this.ZV30GAMRRepositoryGUID = "" ;
   this.OV30GAMRRepositoryGUID = "" ;
   this.AV57AutovalidateExternalTokenAndRefresh = false ;
   this.ZV57AutovalidateExternalTokenAndRefresh = false ;
   this.OV57AutovalidateExternalTokenAndRefresh = false ;
   this.AV47WSVersion = "" ;
   this.ZV47WSVersion = "" ;
   this.OV47WSVersion = "" ;
   this.AV41WSPrivateEncryptKey = "" ;
   this.ZV41WSPrivateEncryptKey = "" ;
   this.OV41WSPrivateEncryptKey = "" ;
   this.AV43WSServerName = "" ;
   this.ZV43WSServerName = "" ;
   this.OV43WSServerName = "" ;
   this.AV44WSServerPort = 0 ;
   this.ZV44WSServerPort = 0 ;
   this.OV44WSServerPort = 0 ;
   this.AV42WSServerBaseURL = "" ;
   this.ZV42WSServerBaseURL = "" ;
   this.OV42WSServerBaseURL = "" ;
   this.AV45WSServerSecureProtocol = 0 ;
   this.ZV45WSServerSecureProtocol = 0 ;
   this.OV45WSServerSecureProtocol = 0 ;
   this.AV46WSTimeout = 0 ;
   this.ZV46WSTimeout = 0 ;
   this.OV46WSTimeout = 0 ;
   this.AV40WSPackage = "" ;
   this.ZV40WSPackage = "" ;
   this.OV40WSPackage = "" ;
   this.AV39WSName = "" ;
   this.ZV39WSName = "" ;
   this.OV39WSName = "" ;
   this.AV38WSExtension = "" ;
   this.ZV38WSExtension = "" ;
   this.OV38WSExtension = "" ;
   this.AV24CusVersion = "" ;
   this.ZV24CusVersion = "" ;
   this.OV24CusVersion = "" ;
   this.AV23CusPrivateEncryptKey = "" ;
   this.ZV23CusPrivateEncryptKey = "" ;
   this.OV23CusPrivateEncryptKey = "" ;
   this.AV21CusFileName = "" ;
   this.ZV21CusFileName = "" ;
   this.OV21CusFileName = "" ;
   this.AV22CusPackage = "" ;
   this.ZV22CusPackage = "" ;
   this.OV22CusPackage = "" ;
   this.AV20CusClassName = "" ;
   this.ZV20CusClassName = "" ;
   this.OV20CusClassName = "" ;
   this.AV87CusMethod = "" ;
   this.ZV87CusMethod = "" ;
   this.OV87CusMethod = "" ;
   this.AV82TFAEnable = false ;
   this.ZV82TFAEnable = false ;
   this.OV82TFAEnable = false ;
   this.AV81TFAAuthenticationTypeName = "" ;
   this.ZV81TFAAuthenticationTypeName = "" ;
   this.OV81TFAAuthenticationTypeName = "" ;
   this.AV83TFAFirstFactorAuthenticationExpiration = 0 ;
   this.ZV83TFAFirstFactorAuthenticationExpiration = 0 ;
   this.OV83TFAFirstFactorAuthenticationExpiration = 0 ;
   this.AV84TFAForceForAllUsers = false ;
   this.ZV84TFAForceForAllUsers = false ;
   this.OV84TFAForceForAllUsers = false ;
   this.AV37TypeId = "" ;
   this.AV34Name = "" ;
   this.AV28FunctionId = "" ;
   this.AV33IsEnable = false ;
   this.AV25Dsc = "" ;
   this.AV36SmallImageName = "" ;
   this.AV14BigImageName = "" ;
   this.AV32Impersonate = "" ;
   this.AV79OTPUseForFirstFactorAuthentication = false ;
   this.AV68OTPEventValidateUser = "" ;
   this.AV70OTPGenerationType = "" ;
   this.AV71OTPGenerationType_CustomEventGenerateCode = "" ;
   this.AV63OTPAutogeneratedCodeLength = 0 ;
   this.AV69OTPGenerateCodeOnlyNumbers = false ;
   this.AV65OTPCodeExpirationTimeout = 0 ;
   this.AV76OTPMaximumDailyNumberCodes = 0 ;
   this.AV78OTPNumberUnsuccessfulRetriesToLockOTP = 0 ;
   this.AV64OTPAutoUnlockTime = 0 ;
   this.AV77OTPNumberUnsuccessfulRetriesToBlockUserBasedOfOTPLocks = 0 ;
   this.AV66OTPEventSendCode = "" ;
   this.AV75OTPMailMessageSubject = "" ;
   this.AV74OTPMailMessageBodyHTML = "" ;
   this.AV67OTPEventValidateCode = "" ;
   this.AV16ClientId = "" ;
   this.AV17ClientSecret = "" ;
   this.AV52VersionPath = "" ;
   this.AV35SiteURL = "" ;
   this.AV85AutocompleteVirtualDirectory = false ;
   this.AV80SiteURLCallbackIsCustom = false ;
   this.AV18ConsumerKey = "" ;
   this.AV19ConsumerSecret = "" ;
   this.AV15CallbackURL = "" ;
   this.AV86CUAutocompleteVirtualDirectory = false ;
   this.AV54AddUserAdditionalDataScope = false ;
   this.AV50AddInitialPropertiesScope = false ;
   this.AV5AdditionalScope = "" ;
   this.AV53GAMRAuthenticationTypeName = "" ;
   this.AV31GAMRServerURL = "" ;
   this.AV29GAMRPrivateEncryptKey = "" ;
   this.AV30GAMRRepositoryGUID = "" ;
   this.AV57AutovalidateExternalTokenAndRefresh = false ;
   this.AV47WSVersion = "" ;
   this.AV41WSPrivateEncryptKey = "" ;
   this.AV43WSServerName = "" ;
   this.AV44WSServerPort = 0 ;
   this.AV42WSServerBaseURL = "" ;
   this.AV45WSServerSecureProtocol = 0 ;
   this.AV46WSTimeout = 0 ;
   this.AV40WSPackage = "" ;
   this.AV39WSName = "" ;
   this.AV38WSExtension = "" ;
   this.AV24CusVersion = "" ;
   this.AV23CusPrivateEncryptKey = "" ;
   this.AV21CusFileName = "" ;
   this.AV22CusPackage = "" ;
   this.AV20CusClassName = "" ;
   this.AV87CusMethod = "" ;
   this.AV82TFAEnable = false ;
   this.AV81TFAAuthenticationTypeName = "" ;
   this.AV83TFAFirstFactorAuthenticationExpiration = 0 ;
   this.AV84TFAForceForAllUsers = false ;
   this.Gx_mode = "" ;
   this.Events = {"e122q2_client": ["'CONFIRM'", true] ,"e132q2_client": ["'GENERATEKEY'", true] ,"e142q2_client": ["'GENERATEKEYCUSTOM'", true] ,"e152q2_client": ["VTFAENABLE.CLICK", true] ,"e162q2_client": ["VOTPGENERATIONTYPE.CLICK", true] ,"e172q2_client": ["'CANCEL'", true] ,"e192q2_client": ["ENTER", true] ,"e202q2_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[{av:'AV33IsEnable',fld:'vISENABLE',pic:''},{av:'AV79OTPUseForFirstFactorAuthentication',fld:'vOTPUSEFORFIRSTFACTORAUTHENTICATION',pic:''},{av:'AV69OTPGenerateCodeOnlyNumbers',fld:'vOTPGENERATECODEONLYNUMBERS',pic:''},{av:'AV85AutocompleteVirtualDirectory',fld:'vAUTOCOMPLETEVIRTUALDIRECTORY',pic:''},{av:'AV80SiteURLCallbackIsCustom',fld:'vSITEURLCALLBACKISCUSTOM',pic:''},{av:'AV86CUAutocompleteVirtualDirectory',fld:'vCUAUTOCOMPLETEVIRTUALDIRECTORY',pic:''},{av:'AV54AddUserAdditionalDataScope',fld:'vADDUSERADDITIONALDATASCOPE',pic:''},{av:'AV50AddInitialPropertiesScope',fld:'vADDINITIALPROPERTIESSCOPE',pic:''},{av:'AV57AutovalidateExternalTokenAndRefresh',fld:'vAUTOVALIDATEEXTERNALTOKENANDREFRESH',pic:''},{av:'AV82TFAEnable',fld:'vTFAENABLE',pic:''},{av:'AV84TFAForceForAllUsers',fld:'vTFAFORCEFORALLUSERS',pic:''}],[]];
   this.EvtParms["'CONFIRM'"] = [[{av:'Gx_mode',fld:'vMODE',pic:'@!'},{av:'AV87CusMethod',fld:'vCUSMETHOD',pic:''},{av:'AV20CusClassName',fld:'vCUSCLASSNAME',pic:''},{av:'AV22CusPackage',fld:'vCUSPACKAGE',pic:''},{av:'AV21CusFileName',fld:'vCUSFILENAME',pic:''},{av:'AV23CusPrivateEncryptKey',fld:'vCUSPRIVATEENCRYPTKEY',pic:''},{ctrl:'vCUSVERSION'},{av:'AV24CusVersion',fld:'vCUSVERSION',pic:''},{ctrl:'vWSSERVERSECUREPROTOCOL'},{av:'AV45WSServerSecureProtocol',fld:'vWSSERVERSECUREPROTOCOL',pic:'9'},{av:'AV42WSServerBaseURL',fld:'vWSSERVERBASEURL',pic:''},{av:'AV44WSServerPort',fld:'vWSSERVERPORT',pic:'ZZZZ9'},{av:'AV43WSServerName',fld:'vWSSERVERNAME',pic:''},{av:'AV38WSExtension',fld:'vWSEXTENSION',pic:''},{av:'AV39WSName',fld:'vWSNAME',pic:''},{av:'AV40WSPackage',fld:'vWSPACKAGE',pic:''},{av:'AV46WSTimeout',fld:'vWSTIMEOUT',pic:'ZZZZ9'},{av:'AV41WSPrivateEncryptKey',fld:'vWSPRIVATEENCRYPTKEY',pic:''},{ctrl:'vWSVERSION'},{av:'AV47WSVersion',fld:'vWSVERSION',pic:''},{av:'AV80SiteURLCallbackIsCustom',fld:'vSITEURLCALLBACKISCUSTOM',pic:''},{av:'AV57AutovalidateExternalTokenAndRefresh',fld:'vAUTOVALIDATEEXTERNALTOKENANDREFRESH',pic:''},{av:'AV30GAMRRepositoryGUID',fld:'vGAMRREPOSITORYGUID',pic:''},{av:'AV29GAMRPrivateEncryptKey',fld:'vGAMRPRIVATEENCRYPTKEY',pic:''},{av:'AV31GAMRServerURL',fld:'vGAMRSERVERURL',pic:''},{av:'AV53GAMRAuthenticationTypeName',fld:'vGAMRAUTHENTICATIONTYPENAME',pic:''},{av:'AV54AddUserAdditionalDataScope',fld:'vADDUSERADDITIONALDATASCOPE',pic:''},{av:'AV50AddInitialPropertiesScope',fld:'vADDINITIALPROPERTIESSCOPE',pic:''},{av:'AV84TFAForceForAllUsers',fld:'vTFAFORCEFORALLUSERS',pic:''},{av:'AV83TFAFirstFactorAuthenticationExpiration',fld:'vTFAFIRSTFACTORAUTHENTICATIONEXPIRATION',pic:'ZZZZZZZZ9'},{ctrl:'vTFAAUTHENTICATIONTYPENAME'},{av:'AV81TFAAuthenticationTypeName',fld:'vTFAAUTHENTICATIONTYPENAME',pic:''},{av:'AV82TFAEnable',fld:'vTFAENABLE',pic:''},{ctrl:'vFUNCTIONID'},{av:'AV28FunctionId',fld:'vFUNCTIONID',pic:''},{ctrl:'vOTPEVENTVALIDATECODE'},{av:'AV67OTPEventValidateCode',fld:'vOTPEVENTVALIDATECODE',pic:''},{av:'AV74OTPMailMessageBodyHTML',fld:'vOTPMAILMESSAGEBODYHTML',pic:''},{av:'AV75OTPMailMessageSubject',fld:'vOTPMAILMESSAGESUBJECT',pic:''},{ctrl:'vOTPEVENTSENDCODE'},{av:'AV66OTPEventSendCode',fld:'vOTPEVENTSENDCODE',pic:''},{av:'AV64OTPAutoUnlockTime',fld:'vOTPAUTOUNLOCKTIME',pic:'ZZZZZZZZ9'},{av:'AV77OTPNumberUnsuccessfulRetriesToBlockUserBasedOfOTPLocks',fld:'vOTPNUMBERUNSUCCESSFULRETRIESTOBLOCKUSERBASEDOFOTPLOCKS',pic:'ZZZ9'},{av:'AV78OTPNumberUnsuccessfulRetriesToLockOTP',fld:'vOTPNUMBERUNSUCCESSFULRETRIESTOLOCKOTP',pic:'ZZZ9'},{av:'AV69OTPGenerateCodeOnlyNumbers',fld:'vOTPGENERATECODEONLYNUMBERS',pic:''},{av:'AV63OTPAutogeneratedCodeLength',fld:'vOTPAUTOGENERATEDCODELENGTH',pic:'ZZZ9'},{av:'AV76OTPMaximumDailyNumberCodes',fld:'vOTPMAXIMUMDAILYNUMBERCODES',pic:'ZZZ9'},{av:'AV65OTPCodeExpirationTimeout',fld:'vOTPCODEEXPIRATIONTIMEOUT',pic:'ZZZZZZZZ9'},{ctrl:'vOTPGENERATIONTYPE_CUSTOMEVENTGENERATECODE'},{av:'AV71OTPGenerationType_CustomEventGenerateCode',fld:'vOTPGENERATIONTYPE_CUSTOMEVENTGENERATECODE',pic:''},{ctrl:'vOTPGENERATIONTYPE'},{av:'AV70OTPGenerationType',fld:'vOTPGENERATIONTYPE',pic:''},{ctrl:'vOTPEVENTVALIDATEUSER'},{av:'AV68OTPEventValidateUser',fld:'vOTPEVENTVALIDATEUSER',pic:''},{av:'AV79OTPUseForFirstFactorAuthentication',fld:'vOTPUSEFORFIRSTFACTORAUTHENTICATION',pic:''},{av:'AV86CUAutocompleteVirtualDirectory',fld:'vCUAUTOCOMPLETEVIRTUALDIRECTORY',pic:''},{av:'AV15CallbackURL',fld:'vCALLBACKURL',pic:''},{av:'AV19ConsumerSecret',fld:'vCONSUMERSECRET',pic:''},{av:'AV18ConsumerKey',fld:'vCONSUMERKEY',pic:''},{av:'AV5AdditionalScope',fld:'vADDITIONALSCOPE',pic:''},{av:'AV85AutocompleteVirtualDirectory',fld:'vAUTOCOMPLETEVIRTUALDIRECTORY',pic:''},{av:'AV35SiteURL',fld:'vSITEURL',pic:''},{av:'AV52VersionPath',fld:'vVERSIONPATH',pic:''},{av:'AV17ClientSecret',fld:'vCLIENTSECRET',pic:''},{av:'AV16ClientId',fld:'vCLIENTID',pic:''},{ctrl:'vIMPERSONATE'},{av:'AV32Impersonate',fld:'vIMPERSONATE',pic:''},{av:'AV14BigImageName',fld:'vBIGIMAGENAME',pic:''},{av:'AV36SmallImageName',fld:'vSMALLIMAGENAME',pic:''},{av:'AV25Dsc',fld:'vDSC',pic:''},{av:'AV33IsEnable',fld:'vISENABLE',pic:''},{av:'AV34Name',fld:'vNAME',pic:''},{ctrl:'vTYPEID'},{av:'AV37TypeId',fld:'vTYPEID',pic:''}],[{ctrl:'WCMESSAGES'}]];
   this.EvtParms["'GENERATEKEY'"] = [[],[{av:'AV41WSPrivateEncryptKey',fld:'vWSPRIVATEENCRYPTKEY',pic:''}]];
   this.EvtParms["'GENERATEKEYCUSTOM'"] = [[],[{av:'AV23CusPrivateEncryptKey',fld:'vCUSPRIVATEENCRYPTKEY',pic:''}]];
   this.EvtParms["VTFAENABLE.CLICK"] = [[{av:'AV82TFAEnable',fld:'vTFAENABLE',pic:''},{av:'AV83TFAFirstFactorAuthenticationExpiration',fld:'vTFAFIRSTFACTORAUTHENTICATIONEXPIRATION',pic:'ZZZZZZZZ9'},{ctrl:'vTFAAUTHENTICATIONTYPENAME'},{av:'AV81TFAAuthenticationTypeName',fld:'vTFAAUTHENTICATIONTYPENAME',pic:''}],[{av:'gx.fn.getCtrlProperty("vTFAFORCEFORALLUSERS","Visible")',ctrl:'vTFAFORCEFORALLUSERS',prop:'Visible'},{av:'AV83TFAFirstFactorAuthenticationExpiration',fld:'vTFAFIRSTFACTORAUTHENTICATIONEXPIRATION',pic:'ZZZZZZZZ9'},{ctrl:'vTFAAUTHENTICATIONTYPENAME'},{av:'AV81TFAAuthenticationTypeName',fld:'vTFAAUTHENTICATIONTYPENAME',pic:''},{av:'gx.fn.getCtrlProperty("TBLTWOFACTORAUTHENTICATION","Visible")',ctrl:'TBLTWOFACTORAUTHENTICATION',prop:'Visible'}]];
   this.EvtParms["VOTPGENERATIONTYPE.CLICK"] = [[{ctrl:'vOTPGENERATIONTYPE'},{av:'AV70OTPGenerationType',fld:'vOTPGENERATIONTYPE',pic:''},{ctrl:'vOTPGENERATIONTYPE_CUSTOMEVENTGENERATECODE'},{av:'AV71OTPGenerationType_CustomEventGenerateCode',fld:'vOTPGENERATIONTYPE_CUSTOMEVENTGENERATECODE',pic:''}],[{av:'gx.fn.getCtrlProperty("TBLOTPCUSTOM","Visible")',ctrl:'TBLOTPCUSTOM',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TBLTYPEOTPGENERATECODE","Visible")',ctrl:'TBLTYPEOTPGENERATECODE',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TBLSENDANDVALIDATEOTPCODE","Visible")',ctrl:'TBLSENDANDVALIDATEOTPCODE',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TBLSENDEMAILBYGAM","Visible")',ctrl:'TBLSENDEMAILBYGAM',prop:'Visible'},{ctrl:'vOTPGENERATIONTYPE_CUSTOMEVENTGENERATECODE'},{av:'AV71OTPGenerationType_CustomEventGenerateCode',fld:'vOTPGENERATIONTYPE_CUSTOMEVENTGENERATECODE',pic:''}]];
   this.EvtParms["'CANCEL'"] = [[{ctrl:'vTYPEID'},{av:'AV37TypeId',fld:'vTYPEID',pic:''},{av:'AV34Name',fld:'vNAME',pic:''},{av:'Gx_mode',fld:'vMODE',pic:'@!'}],[]];
   this.EvtParms["ENTER"] = [[],[]];
   this.EvtParms["VALIDV_FUNCTIONID"] = [[],[]];
   this.EvtParms["VALIDV_OTPGENERATIONTYPE"] = [[],[]];
   this.EvtParms["VALIDV_WSVERSION"] = [[],[]];
   this.EvtParms["VALIDV_CUSVERSION"] = [[],[]];
   this.setVCMap("Gx_mode", "vMODE", 0, "char", 3, 0);
   this.Initialize( );
   this.setComponent({id: "WCMESSAGES" ,GXClass: null , Prefix: "W0402" , lvl: 1 });
});
