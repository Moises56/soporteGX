/*
               File: GAM_UserTOTPActivation
        Description: TOTP activation
             Author: GeneXus .NET Framework Generator version 18_0_5-175581
       Generated on: 8/24/2023 18:27:4.66
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_usertotpactivation', false, function () {
   this.ServerClass =  "gam_usertotpactivation" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_usertotpactivation.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = true;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.AV23UserGUID=gx.fn.getControlValue("vUSERGUID") ;
   };
   this.s122_client=function()
   {
      /* 'SHOWMESSAGES' Routine */
      this.createWebComponent('Wcmessages','GAM_Messages',[]);
   };
   this.e12332_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e14331_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,7,8,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,37,38,39,40,41,42,43,44,45,46];
   this.GXLastCtrlId =46;
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"GAM_DATACARD",grid:0};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id: 14, fld:"GAM_DATACARD_TABLEGENERALTITLE",grid:0};
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"GAM_DATACARD_TBTITLEGENERAL", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"GAM_DATACARD_TABLEDATAGENERAL",grid:0};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[23]={ id: 23, fld:"QRIMAGE", format:1,grid:0, ctrltype: "textblock"};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[25]={ id: 25, fld:"",grid:0};
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id:28 ,lvl:0,type:"svchar",len:256,dec:0,sign:false,ro:0,multiline:true,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSECRETKEY",fmt:0,gxz:"ZV12SecretKey",gxold:"OV12SecretKey",gxvar:"AV12SecretKey",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV12SecretKey=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV12SecretKey=Value},v2c:function(){gx.fn.setControlValue("vSECRETKEY",gx.O.AV12SecretKey,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV12SecretKey=this.val()},val:function(){return gx.fn.getControlValue("vSECRETKEY")},nac:gx.falseFn};
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[30]={ id: 30, fld:"",grid:0};
   GXValidFnc[31]={ id: 31, fld:"",grid:0};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id:33 ,lvl:0,type:"svchar",len:8,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vTOTPCODE",fmt:0,gxz:"ZV13TOTPCode",gxold:"OV13TOTPCode",gxvar:"AV13TOTPCode",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV13TOTPCode=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV13TOTPCode=Value},v2c:function(){gx.fn.setControlValue("vTOTPCODE",gx.O.AV13TOTPCode,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV13TOTPCode=this.val()},val:function(){return gx.fn.getControlValue("vTOTPCODE")},nac:gx.falseFn};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[35]={ id: 35, fld:"",grid:0};
   GXValidFnc[37]={ id: 37, fld:"",grid:0};
   GXValidFnc[38]={ id: 38, fld:"",grid:0};
   GXValidFnc[39]={ id: 39, fld:"GAM_FOOTERENTRY",grid:0};
   GXValidFnc[40]={ id: 40, fld:"",grid:0};
   GXValidFnc[41]={ id: 41, fld:"",grid:0};
   GXValidFnc[42]={ id: 42, fld:"GAM_FOOTERENTRY_TABLEBUTTONS",grid:0};
   GXValidFnc[43]={ id: 43, fld:"",grid:0};
   GXValidFnc[44]={ id: 44, fld:"GAM_FOOTERENTRY_BTNCANCEL",grid:0,evt:"e14331_client"};
   GXValidFnc[45]={ id: 45, fld:"",grid:0};
   GXValidFnc[46]={ id: 46, fld:"GAM_FOOTERENTRY_BTNCONFIRM",grid:0,evt:"e12332_client",std:"ENTER"};
   this.AV12SecretKey = "" ;
   this.ZV12SecretKey = "" ;
   this.OV12SecretKey = "" ;
   this.AV13TOTPCode = "" ;
   this.ZV13TOTPCode = "" ;
   this.OV13TOTPCode = "" ;
   this.AV12SecretKey = "" ;
   this.AV13TOTPCode = "" ;
   this.AV23UserGUID = "" ;
   this.Events = {"e12332_client": ["ENTER", true] ,"e14331_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[{av:'AV12SecretKey',fld:'vSECRETKEY',pic:''}],[]];
   this.EvtParms["ENTER"] = [[{av:'AV23UserGUID',fld:'vUSERGUID',pic:''},{av:'AV13TOTPCode',fld:'vTOTPCODE',pic:''}],[{ctrl:'GAM_FOOTERENTRY_BTNCONFIRM',prop:'Visible'},{av:'AV23UserGUID',fld:'vUSERGUID',pic:''},{ctrl:'WCMESSAGES'}]];
   this.EnterCtrl = ["GAM_FOOTERENTRY_BTNCONFIRM"];
   this.setVCMap("AV23UserGUID", "vUSERGUID", 0, "char", 40, 0);
   this.Initialize( );
   this.setComponent({id: "WCHEADER" ,GXClass: null , Prefix: "W0006" , lvl: 1 });
   this.setComponent({id: "WCGENERALUSERINFO" ,GXClass: null , Prefix: "W0009" , lvl: 1 });
   this.setComponent({id: "WCMESSAGES" ,GXClass: null , Prefix: "W0036" , lvl: 1 });
});
gx.wi( function() { gx.createParentObj(this.gam_usertotpactivation);});
