/*
               File: GAM_Login
        Description: Login
             Author: GeneXus .NET Framework Generator version 18_0_5-175581
       Generated on: 8/24/2023 18:27:11.17
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_login', false, function () {
   this.ServerClass =  "gam_login" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_login.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = true;
   this.skipOnEnter = false;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.AV20KeepMeLoggedIn=gx.fn.getControlValue("vKEEPMELOGGEDIN") ;
      this.AV25RememberMe=gx.fn.getControlValue("vREMEMBERME") ;
      this.AV37IDP_State=gx.fn.getControlValue("vIDP_STATE") ;
   };
   this.e132v2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e152v2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,23,24,25];
   this.GXLastCtrlId =25;
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TBTITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"TBCURRENTREPOSITORY", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id:14 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERNAME",fmt:0,gxz:"ZV31UserName",gxold:"OV31UserName",gxvar:"AV31UserName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV31UserName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV31UserName=Value},v2c:function(){gx.fn.setControlValue("vUSERNAME",gx.O.AV31UserName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV31UserName=this.val()},val:function(){return gx.fn.getControlValue("vUSERNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 14 , function() {
   });
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id:19 ,lvl:0,type:"char",len:50,dec:0,sign:false,isPwd:true,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERPASSWORD",fmt:0,gxz:"ZV32UserPassword",gxold:"OV32UserPassword",gxvar:"AV32UserPassword",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV32UserPassword=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV32UserPassword=Value},v2c:function(){gx.fn.setControlValue("vUSERPASSWORD",gx.O.AV32UserPassword,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV32UserPassword=this.val()},val:function(){return gx.fn.getControlValue("vUSERPASSWORD")},nac:gx.falseFn};
   this.declareDomainHdlr( 19 , function() {
   });
   GXValidFnc[20]={ id: 20, fld:"",grid:0};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[25]={ id: 25, fld:"LOGIN",grid:0,evt:"e132v2_client",std:"ENTER"};
   this.AV31UserName = "" ;
   this.ZV31UserName = "" ;
   this.OV31UserName = "" ;
   this.AV32UserPassword = "" ;
   this.ZV32UserPassword = "" ;
   this.OV32UserPassword = "" ;
   this.AV31UserName = "" ;
   this.AV32UserPassword = "" ;
   this.AV20KeepMeLoggedIn = false ;
   this.AV25RememberMe = false ;
   this.AV37IDP_State = "" ;
   this.Events = {"e132v2_client": ["ENTER", true] ,"e152v2_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[{av:'AV20KeepMeLoggedIn',fld:'vKEEPMELOGGEDIN',pic:'',hsh:true},{av:'AV25RememberMe',fld:'vREMEMBERME',pic:'',hsh:true}],[{av:'gx.fn.getCtrlProperty("vUSERNAME","Invitemessage")',ctrl:'vUSERNAME',prop:'Invitemessage'},{av:'AV32UserPassword',fld:'vUSERPASSWORD',pic:''}]];
   this.EvtParms["ENTER"] = [[{av:'AV20KeepMeLoggedIn',fld:'vKEEPMELOGGEDIN',pic:'',hsh:true},{av:'AV25RememberMe',fld:'vREMEMBERME',pic:'',hsh:true},{av:'AV31UserName',fld:'vUSERNAME',pic:''},{av:'AV32UserPassword',fld:'vUSERPASSWORD',pic:''},{av:'AV37IDP_State',fld:'vIDP_STATE',pic:''}],[{av:'AV37IDP_State',fld:'vIDP_STATE',pic:''},{av:'AV32UserPassword',fld:'vUSERPASSWORD',pic:''}]];
   this.EnterCtrl = ["LOGIN"];
   this.setVCMap("AV20KeepMeLoggedIn", "vKEEPMELOGGEDIN", 0, "boolean", 4, 0);
   this.setVCMap("AV25RememberMe", "vREMEMBERME", 0, "boolean", 4, 0);
   this.setVCMap("AV37IDP_State", "vIDP_STATE", 0, "char", 60, 0);
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(this.gam_login);});
