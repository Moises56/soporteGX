/*
               File: GAM_AppPermissionChildren
        Description: Permission application`s children
             Author: GeneXus .NET Framework Generator version 18_0_5-175581
       Generated on: 8/24/2023 18:25:47.85
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_apppermissionchildren', false, function () {
   this.ServerClass =  "gam_apppermissionchildren" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_apppermissionchildren.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.AV7ApplicationId=gx.fn.getIntegerValue("vAPPLICATIONID",gx.thousandSeparator) ;
      this.AV21PermissionId=gx.fn.getControlValue("vPERMISSIONID") ;
      this.AV22PermissionList=gx.fn.getControlValue("vPERMISSIONLIST") ;
      this.subGridww_Recordcount=gx.fn.getIntegerValue("subGridww_Recordcount",gx.thousandSeparator) ;
   };
   this.Validv_Accesstype=function()
   {
      var currentRow = gx.fn.currentGridRowImpl(31);
      return this.validCliEvt("Validv_Accesstype", 31, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vACCESSTYPE");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV6AccessType , "A" ) == 0 || gx.text.compare( this.AV6AccessType , "R" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Default Access"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.e151e2_client=function()
   {
      /* Btnchildren_Click Routine */
      this.clearMessages();
      this.call("gam_apppermissionchildren.aspx", [this.AV7ApplicationId, this.AV17Id], null, ["ApplicationId","PermissionId"]);
      this.refreshOutputs([{av:'AV17Id',fld:'vID',pic:''},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e141e2_client=function()
   {
      /* Btndlt_Click Routine */
      return this.executeServerEvent("VBTNDLT.CLICK", true, arguments[0], false, false);
   };
   this.e111e2_client=function()
   {
      /* 'AddNew' Routine */
      return this.executeServerEvent("'ADDNEW'", false, null, false, false);
   };
   this.e121e2_client=function()
   {
      /* Gam_headerwwback_tableback_Click Routine */
      return this.executeServerEvent("GAM_HEADERWWBACK_TABLEBACK.CLICK", true, null, false, true);
   };
   this.e161e2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e171e2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, arguments[0], false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,32,33,34,35,36,37];
   this.GXLastCtrlId =37;
   this.GridwwContainer = new gx.grid.grid(this, 2,"WbpLvl2",31,"Gridww","Gridww","GridwwContainer",this.CmpContext,this.IsMasterPage,"gam_apppermissionchildren",[],false,1,false,true,10,true,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),true,false,false,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridwwContainer = this.GridwwContainer;
   GridwwContainer.addSingleLineEdit("Name",32,"vNAME",gx.getMessage( "Permission name"),"","Name","char",250,"px",120,80,"start",null,[],"Name","Name",true,0,false,false,"Attribute",0,"");
   GridwwContainer.addSingleLineEdit("Dsc",33,"vDSC",gx.getMessage( "Description"),"","Dsc","char",300,"px",254,80,"start",null,[],"Dsc","Dsc",true,0,false,false,"Attribute",0,"WWSecondaryColumn");
   GridwwContainer.addComboBox("Accesstype",34,"vACCESSTYPE",gx.getMessage( "Default Access"),"AccessType","char",null,0,true,false,50,"px","WWOptionalColumn");
   GridwwContainer.addSingleLineEdit("Btnchildren",35,"vBTNCHILDREN","","","BtnChildren","char",0,"px",20,20,"start","e151e2_client",[],"Btnchildren","BtnChildren",true,0,false,false,"TextActionAttribute",0,"WWTextActionColumn");
   GridwwContainer.addSingleLineEdit("Btndlt",36,"vBTNDLT","","","BtnDlt","char",0,"px",20,20,"start","e141e2_client",[],"Btndlt","BtnDlt",true,0,false,false,"TextActionAttribute",0,"WWTextActionColumn");
   GridwwContainer.addSingleLineEdit("Id",37,"vID",gx.getMessage( "GUID"),"","Id","char",0,"px",40,40,"start",null,[],"Id","Id",false,0,false,false,"Attribute",0,"");
   this.GridwwContainer.emptyText = gx.getMessage( "No results found.");
   this.setGrid(GridwwContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"GAM_HEADERWWBACK",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"GAM_HEADERWWBACK_TBLBACKCONTAINER",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"GAM_HEADERWWBACK_TABLEBACK",grid:0,evt:"e121e2_client"};
   GXValidFnc[15]={ id: 15, fld:"GAM_HEADERWWBACK_TXTBACK", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"GAM_HEADERWWBACK_TABLEACTIONS",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"GAM_HEADERWWBACK_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"GAM_HEADERWWBACK_ADDNEW",grid:0,evt:"e111e2_client"};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[25]={ id:25 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSEARCH",fmt:0,gxz:"ZV26Search",gxold:"OV26Search",gxvar:"AV26Search",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV26Search=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV26Search=Value},v2c:function(){gx.fn.setControlValue("vSEARCH",gx.O.AV26Search,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV26Search=this.val()},val:function(){return gx.fn.getControlValue("vSEARCH")},nac:gx.falseFn};
   this.declareDomainHdlr( 25 , function() {
   });
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id: 28, fld:"GRIDCONTAINER",grid:0};
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[30]={ id: 30, fld:"",grid:0};
   GXValidFnc[32]={ id:32 ,lvl:2,type:"char",len:120,dec:0,sign:false,ro:0,isacc:0,grid:31,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",fmt:0,gxz:"ZV20Name",gxold:"OV20Name",gxvar:"AV20Name",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV20Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV20Name=Value},v2c:function(row){gx.fn.setGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(31),gx.O.AV20Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV20Name=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(31))},nac:gx.falseFn};
   GXValidFnc[33]={ id:33 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:31,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDSC",fmt:0,gxz:"ZV12Dsc",gxold:"OV12Dsc",gxvar:"AV12Dsc",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV12Dsc=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV12Dsc=Value},v2c:function(row){gx.fn.setGridControlValue("vDSC",row || gx.fn.currentGridRowImpl(31),gx.O.AV12Dsc,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV12Dsc=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vDSC",row || gx.fn.currentGridRowImpl(31))},nac:gx.falseFn};
   GXValidFnc[34]={ id:34 ,lvl:2,type:"char",len:1,dec:0,sign:false,ro:0,isacc:0,grid:31,gxgrid:this.GridwwContainer,fnc:this.Validv_Accesstype,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vACCESSTYPE",fmt:0,gxz:"ZV6AccessType",gxold:"OV6AccessType",gxvar:"AV6AccessType",ucs:[],op:[34],ip:[34],nacdep:[],ctrltype:"combo",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV6AccessType=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV6AccessType=Value},v2c:function(row){gx.fn.setGridComboBoxValue("vACCESSTYPE",row || gx.fn.currentGridRowImpl(31),gx.O.AV6AccessType);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV6AccessType=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vACCESSTYPE",row || gx.fn.currentGridRowImpl(31))},nac:gx.falseFn};
   GXValidFnc[35]={ id:35 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:31,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNCHILDREN",fmt:0,gxz:"ZV10BtnChildren",gxold:"OV10BtnChildren",gxvar:"AV10BtnChildren",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV10BtnChildren=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV10BtnChildren=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNCHILDREN",row || gx.fn.currentGridRowImpl(31),gx.O.AV10BtnChildren,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV10BtnChildren=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNCHILDREN",row || gx.fn.currentGridRowImpl(31))},nac:gx.falseFn,evt:"e151e2_client"};
   GXValidFnc[36]={ id:36 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:31,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNDLT",fmt:0,gxz:"ZV11BtnDlt",gxold:"OV11BtnDlt",gxvar:"AV11BtnDlt",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV11BtnDlt=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV11BtnDlt=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNDLT",row || gx.fn.currentGridRowImpl(31),gx.O.AV11BtnDlt,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV11BtnDlt=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNDLT",row || gx.fn.currentGridRowImpl(31))},nac:gx.falseFn,evt:"e141e2_client"};
   GXValidFnc[37]={ id:37 ,lvl:2,type:"char",len:40,dec:0,sign:false,ro:0,isacc:0,grid:31,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vID",fmt:0,gxz:"ZV17Id",gxold:"OV17Id",gxvar:"AV17Id",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV17Id=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV17Id=Value},v2c:function(row){gx.fn.setGridControlValue("vID",row || gx.fn.currentGridRowImpl(31),gx.O.AV17Id,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV17Id=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vID",row || gx.fn.currentGridRowImpl(31))},nac:gx.falseFn};
   this.AV26Search = "" ;
   this.ZV26Search = "" ;
   this.OV26Search = "" ;
   this.ZV20Name = "" ;
   this.OV20Name = "" ;
   this.ZV12Dsc = "" ;
   this.OV12Dsc = "" ;
   this.ZV6AccessType = "" ;
   this.OV6AccessType = "" ;
   this.ZV10BtnChildren = "" ;
   this.OV10BtnChildren = "" ;
   this.ZV11BtnDlt = "" ;
   this.OV11BtnDlt = "" ;
   this.ZV17Id = "" ;
   this.OV17Id = "" ;
   this.AV26Search = "" ;
   this.AV7ApplicationId = 0 ;
   this.AV21PermissionId = "" ;
   this.AV20Name = "" ;
   this.AV12Dsc = "" ;
   this.AV6AccessType = "" ;
   this.AV10BtnChildren = "" ;
   this.AV11BtnDlt = "" ;
   this.AV17Id = "" ;
   this.AV22PermissionList = [ ] ;
   this.Events = {"e141e2_client": ["VBTNDLT.CLICK", true] ,"e111e2_client": ["'ADDNEW'", true] ,"e121e2_client": ["GAM_HEADERWWBACK_TABLEBACK.CLICK", true] ,"e161e2_client": ["ENTER", true] ,"e171e2_client": ["CANCEL", true] ,"e151e2_client": ["VBTNCHILDREN.CLICK", false]};
   this.EvtParms["REFRESH"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV21PermissionId',fld:'vPERMISSIONID',pic:''},{av:'AV26Search',fld:'vSEARCH',pic:''},{av:'AV22PermissionList',fld:'vPERMISSIONLIST',pic:''}],[]];
   this.EvtParms["GRIDWW.LOAD"] = [[{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV21PermissionId',fld:'vPERMISSIONID',pic:''},{av:'AV26Search',fld:'vSEARCH',pic:''},{av:'AV22PermissionList',fld:'vPERMISSIONLIST',pic:''}],[{av:'gx.fn.getCtrlProperty("GAM_HEADERWWBACK_TITLE","Caption")',ctrl:'GAM_HEADERWWBACK_TITLE',prop:'Caption'},{av:'AV11BtnDlt',fld:'vBTNDLT',pic:''},{av:'AV10BtnChildren',fld:'vBTNCHILDREN',pic:''},{av:'AV17Id',fld:'vID',pic:''},{av:'AV20Name',fld:'vNAME',pic:''},{av:'AV12Dsc',fld:'vDSC',pic:''},{ctrl:'vACCESSTYPE'},{av:'AV6AccessType',fld:'vACCESSTYPE',pic:''},{av:'AV22PermissionList',fld:'vPERMISSIONLIST',pic:''}]];
   this.EvtParms["VBTNDLT.CLICK"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV21PermissionId',fld:'vPERMISSIONID',pic:''},{av:'AV26Search',fld:'vSEARCH',pic:''},{av:'AV22PermissionList',fld:'vPERMISSIONLIST',pic:''},{av:'AV17Id',fld:'vID',pic:''}],[]];
   this.EvtParms["VBTNCHILDREN.CLICK"] = [[{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV17Id',fld:'vID',pic:''}],[{av:'AV17Id',fld:'vID',pic:''},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["'ADDNEW'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV21PermissionId',fld:'vPERMISSIONID',pic:''},{av:'AV26Search',fld:'vSEARCH',pic:''},{av:'AV22PermissionList',fld:'vPERMISSIONLIST',pic:''}],[{av:'AV21PermissionId',fld:'vPERMISSIONID',pic:''},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["GAM_HEADERWWBACK_TABLEBACK.CLICK"] = [[{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV22PermissionList',fld:'vPERMISSIONLIST',pic:''}],[{av:'AV22PermissionList',fld:'vPERMISSIONLIST',pic:''},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["ENTER"] = [[],[]];
   this.EvtParms["GRIDWW_FIRSTPAGE"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV21PermissionId',fld:'vPERMISSIONID',pic:''},{av:'AV26Search',fld:'vSEARCH',pic:''},{av:'AV22PermissionList',fld:'vPERMISSIONLIST',pic:''}],[]];
   this.EvtParms["GRIDWW_PREVPAGE"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV21PermissionId',fld:'vPERMISSIONID',pic:''},{av:'AV26Search',fld:'vSEARCH',pic:''},{av:'AV22PermissionList',fld:'vPERMISSIONLIST',pic:''}],[]];
   this.EvtParms["GRIDWW_NEXTPAGE"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV21PermissionId',fld:'vPERMISSIONID',pic:''},{av:'AV26Search',fld:'vSEARCH',pic:''},{av:'AV22PermissionList',fld:'vPERMISSIONLIST',pic:''}],[]];
   this.EvtParms["GRIDWW_LASTPAGE"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV21PermissionId',fld:'vPERMISSIONID',pic:''},{av:'AV26Search',fld:'vSEARCH',pic:''},{av:'AV22PermissionList',fld:'vPERMISSIONLIST',pic:''},{av:'subGridww_Recordcount'}],[]];
   this.EvtParms["VALIDV_ACCESSTYPE"] = [[{ctrl:'vACCESSTYPE'},{av:'AV6AccessType',fld:'vACCESSTYPE',pic:''}],[{ctrl:'vACCESSTYPE'},{av:'AV6AccessType',fld:'vACCESSTYPE',pic:''}]];
   this.setVCMap("AV7ApplicationId", "vAPPLICATIONID", 0, "int", 12, 0);
   this.setVCMap("AV21PermissionId", "vPERMISSIONID", 0, "char", 40, 0);
   this.setVCMap("AV22PermissionList", "vPERMISSIONLIST", 0, "Collchar", 0, 0);
   this.setVCMap("AV7ApplicationId", "vAPPLICATIONID", 0, "int", 12, 0);
   this.setVCMap("AV21PermissionId", "vPERMISSIONID", 0, "char", 40, 0);
   this.setVCMap("AV22PermissionList", "vPERMISSIONLIST", 0, "Collchar", 0, 0);
   this.setVCMap("AV7ApplicationId", "vAPPLICATIONID", 0, "int", 12, 0);
   this.setVCMap("AV21PermissionId", "vPERMISSIONID", 0, "char", 40, 0);
   this.setVCMap("AV22PermissionList", "vPERMISSIONLIST", 0, "Collchar", 0, 0);
   GridwwContainer.addRefreshingParm({rfrProp:"Rows", gxGrid:"Gridww"});
   GridwwContainer.addRefreshingVar({rfrVar:"AV7ApplicationId"});
   GridwwContainer.addRefreshingVar({rfrVar:"AV21PermissionId"});
   GridwwContainer.addRefreshingVar(this.GXValidFnc[25]);
   GridwwContainer.addRefreshingVar({rfrVar:"AV22PermissionList"});
   GridwwContainer.addRefreshingParm({rfrVar:"AV7ApplicationId"});
   GridwwContainer.addRefreshingParm({rfrVar:"AV21PermissionId"});
   GridwwContainer.addRefreshingParm(this.GXValidFnc[25]);
   GridwwContainer.addRefreshingParm({rfrVar:"AV22PermissionList"});
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(this.gam_apppermissionchildren);});
