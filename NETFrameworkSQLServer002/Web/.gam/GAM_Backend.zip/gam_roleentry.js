/*
               File: GAM_RoleEntry
        Description: Role
             Author: GeneXus .NET Framework Generator version 18_0_5-175581
       Generated on: 8/24/2023 18:24:32.22
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_roleentry', false, function () {
   this.ServerClass =  "gam_roleentry" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_roleentry.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.Gx_mode=gx.fn.getControlValue("vMODE") ;
   };
   this.s112_client=function()
   {
      /* 'SHOWMESSAGES' Routine */
      this.createWebComponent('Wcmessages','GAM_Messages',[]);
   };
   this.e13091_client=function()
   {
      /* 'RolePermissions' Routine */
      this.clearMessages();
      this.call("gam_wwrolepermissions.aspx", [this.AV11Id, 0], null, ["RoleId","pApplicationId"]);
      this.refreshOutputs([{av:'AV11Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e12091_client=function()
   {
      /* 'DeleteRole' Routine */
      this.clearMessages();
      this.call("gam_roleentry.aspx", ["DLT", this.AV11Id], null, ["Mode","Id"]);
      this.refreshOutputs([{av:'AV11Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e11091_client=function()
   {
      /* 'Edit' Routine */
      this.clearMessages();
      this.call("gam_roleentry.aspx", ["UPD", this.AV11Id], null, ["Mode","Id"]);
      this.refreshOutputs([{av:'AV11Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e20091_client=function()
   {
      /* Gam_headerentry_tableback_Click Routine */
      this.clearMessages();
      this.call("gam_wwroles.aspx", [], null, []);
      this.refreshOutputs([]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e15092_client=function()
   {
      /* 'Confirm' Routine */
      return this.executeServerEvent("'CONFIRM'", false, null, false, false);
   };
   this.e16092_client=function()
   {
      /* 'Cancel' Routine */
      return this.executeServerEvent("'CANCEL'", false, null, false, false);
   };
   this.e17092_client=function()
   {
      /* 'RoleChildren' Routine */
      return this.executeServerEvent("'ROLECHILDREN'", true, null, false, false);
   };
   this.e18092_client=function()
   {
      /* 'CopyRole' Routine */
      return this.executeServerEvent("'COPYROLE'", true, null, false, false);
   };
   this.e21092_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e22092_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,88,89,90,91,92,93,94,95,96,97];
   this.GXLastCtrlId =97;
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"GAM_HEADERENTRY",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"GAM_HEADERENTRY_TBLBACKCONTAINER",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"GAM_HEADERENTRY_TABLEBACK",grid:0,evt:"e20091_client"};
   GXValidFnc[15]={ id: 15, fld:"GAM_HEADERENTRY_TXTBACK", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"GAM_HEADERENTRY_TABLETITLEACTIONS",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"GAM_HEADERENTRY_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"GAM_HEADERENTRY_TXTSTATUS", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"GAM_HEADERENTRY_TBLTOOLBARS",grid:0};
   GXValidFnc[25]={ id: 25, fld:"",grid:0};
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id: 28, fld:"", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[29]={ id: 29, fld:"GAM_HEADERENTRY_BUTTONSTOOLBAR_INNER",grid:0};
   GXValidFnc[30]={ id: 30, fld:"BUTTONEDIT", format:0,grid:0,evt:"e11091_client", ctrltype: "textblock"};
   GXValidFnc[31]={ id: 31, fld:"BUTTONDELETE", format:0,grid:0,evt:"e12091_client", ctrltype: "textblock"};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"GAM_HEADERENTRY_MENUTABLE",grid:0};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[35]={ id: 35, fld:"",grid:0};
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[37]={ id: 37, fld:"", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[38]={ id: 38, fld:"GAM_HEADERENTRY_MENUTOOLBAR_INNER",grid:0};
   GXValidFnc[39]={ id: 39, fld:"", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[40]={ id: 40, fld:"BUTTONCHILDREN", format:0,grid:0,evt:"e17092_client", ctrltype: "textblock"};
   GXValidFnc[41]={ id: 41, fld:"BUTTONPERMISSIONS", format:0,grid:0,evt:"e13091_client", ctrltype: "textblock"};
   GXValidFnc[42]={ id: 42, fld:"BTNCOPYROLE", format:0,grid:0,evt:"e18092_client", ctrltype: "textblock"};
   GXValidFnc[43]={ id: 43, fld:"",grid:0};
   GXValidFnc[44]={ id: 44, fld:"",grid:0};
   GXValidFnc[45]={ id: 45, fld:"GAM_DATACARD",grid:0};
   GXValidFnc[46]={ id: 46, fld:"",grid:0};
   GXValidFnc[47]={ id: 47, fld:"",grid:0};
   GXValidFnc[48]={ id: 48, fld:"GAM_DATACARD_TABLEGENERALTITLE",grid:0};
   GXValidFnc[49]={ id: 49, fld:"",grid:0};
   GXValidFnc[50]={ id: 50, fld:"",grid:0};
   GXValidFnc[51]={ id: 51, fld:"GAM_DATACARD_TBTITLEGENERAL", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[52]={ id: 52, fld:"",grid:0};
   GXValidFnc[53]={ id: 53, fld:"",grid:0};
   GXValidFnc[54]={ id: 54, fld:"GAM_DATACARD_TABLEDATAGENERAL",grid:0};
   GXValidFnc[55]={ id: 55, fld:"",grid:0};
   GXValidFnc[56]={ id: 56, fld:"",grid:0};
   GXValidFnc[57]={ id: 57, fld:"",grid:0};
   GXValidFnc[58]={ id: 58, fld:"",grid:0};
   GXValidFnc[59]={ id:59 ,lvl:0,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:1,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vID",fmt:0,gxz:"ZV11Id",gxold:"OV11Id",gxvar:"AV11Id",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV11Id=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV11Id=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vID",gx.O.AV11Id,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV11Id=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vID",gx.thousandSeparator)},nac:gx.falseFn};
   this.declareDomainHdlr( 59 , function() {
   });
   GXValidFnc[60]={ id: 60, fld:"",grid:0};
   GXValidFnc[61]={ id: 61, fld:"",grid:0};
   GXValidFnc[62]={ id: 62, fld:"",grid:0};
   GXValidFnc[63]={ id: 63, fld:"",grid:0};
   GXValidFnc[64]={ id:64 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGUID",fmt:0,gxz:"ZV10GUID",gxold:"OV10GUID",gxvar:"AV10GUID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV10GUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV10GUID=Value},v2c:function(){gx.fn.setControlValue("vGUID",gx.O.AV10GUID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV10GUID=this.val()},val:function(){return gx.fn.getControlValue("vGUID")},nac:gx.falseFn};
   this.declareDomainHdlr( 64 , function() {
   });
   GXValidFnc[65]={ id: 65, fld:"",grid:0};
   GXValidFnc[66]={ id: 66, fld:"",grid:0};
   GXValidFnc[67]={ id: 67, fld:"",grid:0};
   GXValidFnc[68]={ id: 68, fld:"",grid:0};
   GXValidFnc[69]={ id:69 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",fmt:0,gxz:"ZV12Name",gxold:"OV12Name",gxvar:"AV12Name",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV12Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV12Name=Value},v2c:function(){gx.fn.setControlValue("vNAME",gx.O.AV12Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV12Name=this.val()},val:function(){return gx.fn.getControlValue("vNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 69 , function() {
   });
   GXValidFnc[70]={ id: 70, fld:"",grid:0};
   GXValidFnc[71]={ id: 71, fld:"",grid:0};
   GXValidFnc[72]={ id: 72, fld:"",grid:0};
   GXValidFnc[73]={ id: 73, fld:"",grid:0};
   GXValidFnc[74]={ id:74 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDSC",fmt:0,gxz:"ZV5Dsc",gxold:"OV5Dsc",gxvar:"AV5Dsc",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV5Dsc=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV5Dsc=Value},v2c:function(){gx.fn.setControlValue("vDSC",gx.O.AV5Dsc,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV5Dsc=this.val()},val:function(){return gx.fn.getControlValue("vDSC")},nac:gx.falseFn};
   this.declareDomainHdlr( 74 , function() {
   });
   GXValidFnc[75]={ id: 75, fld:"",grid:0};
   GXValidFnc[76]={ id: 76, fld:"",grid:0};
   GXValidFnc[77]={ id: 77, fld:"",grid:0};
   GXValidFnc[78]={ id: 78, fld:"",grid:0};
   GXValidFnc[79]={ id:79 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vEXTID",fmt:0,gxz:"ZV8ExtId",gxold:"OV8ExtId",gxvar:"AV8ExtId",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV8ExtId=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV8ExtId=Value},v2c:function(){gx.fn.setControlValue("vEXTID",gx.O.AV8ExtId,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV8ExtId=this.val()},val:function(){return gx.fn.getControlValue("vEXTID")},nac:gx.falseFn};
   this.declareDomainHdlr( 79 , function() {
   });
   GXValidFnc[80]={ id: 80, fld:"",grid:0};
   GXValidFnc[81]={ id: 81, fld:"",grid:0};
   GXValidFnc[82]={ id: 82, fld:"",grid:0};
   GXValidFnc[83]={ id: 83, fld:"",grid:0};
   GXValidFnc[84]={ id:84 ,lvl:0,type:"int",len:9,dec:0,sign:false,pic:"ZZZZZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSECPOLID",fmt:0,gxz:"ZV14SecPolId",gxold:"OV14SecPolId",gxvar:"AV14SecPolId",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV14SecPolId=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV14SecPolId=gx.num.intval(Value)},v2c:function(){gx.fn.setComboBoxValue("vSECPOLID",gx.O.AV14SecPolId);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV14SecPolId=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vSECPOLID",gx.thousandSeparator)},nac:gx.falseFn};
   this.declareDomainHdlr( 84 , function() {
   });
   GXValidFnc[85]={ id: 85, fld:"",grid:0};
   GXValidFnc[86]={ id: 86, fld:"",grid:0};
   GXValidFnc[88]={ id: 88, fld:"",grid:0};
   GXValidFnc[89]={ id: 89, fld:"",grid:0};
   GXValidFnc[90]={ id: 90, fld:"GAM_FOOTERENTRY",grid:0};
   GXValidFnc[91]={ id: 91, fld:"",grid:0};
   GXValidFnc[92]={ id: 92, fld:"",grid:0};
   GXValidFnc[93]={ id: 93, fld:"GAM_FOOTERENTRY_TABLEBUTTONS",grid:0};
   GXValidFnc[94]={ id: 94, fld:"",grid:0};
   GXValidFnc[95]={ id: 95, fld:"GAM_FOOTERENTRY_BTNCANCEL",grid:0,evt:"e16092_client"};
   GXValidFnc[96]={ id: 96, fld:"",grid:0};
   GXValidFnc[97]={ id: 97, fld:"GAM_FOOTERENTRY_BTNCONFIRM",grid:0,evt:"e15092_client"};
   this.AV11Id = 0 ;
   this.ZV11Id = 0 ;
   this.OV11Id = 0 ;
   this.AV10GUID = "" ;
   this.ZV10GUID = "" ;
   this.OV10GUID = "" ;
   this.AV12Name = "" ;
   this.ZV12Name = "" ;
   this.OV12Name = "" ;
   this.AV5Dsc = "" ;
   this.ZV5Dsc = "" ;
   this.OV5Dsc = "" ;
   this.AV8ExtId = "" ;
   this.ZV8ExtId = "" ;
   this.OV8ExtId = "" ;
   this.AV14SecPolId = 0 ;
   this.ZV14SecPolId = 0 ;
   this.OV14SecPolId = 0 ;
   this.AV11Id = 0 ;
   this.AV10GUID = "" ;
   this.AV12Name = "" ;
   this.AV5Dsc = "" ;
   this.AV8ExtId = "" ;
   this.AV14SecPolId = 0 ;
   this.Gx_mode = "" ;
   this.Events = {"e15092_client": ["'CONFIRM'", true] ,"e16092_client": ["'CANCEL'", true] ,"e17092_client": ["'ROLECHILDREN'", true] ,"e18092_client": ["'COPYROLE'", true] ,"e21092_client": ["ENTER", true] ,"e22092_client": ["CANCEL", true] ,"e13091_client": ["'ROLEPERMISSIONS'", false] ,"e12091_client": ["'DELETEROLE'", false] ,"e11091_client": ["'EDIT'", false] ,"e20091_client": ["GAM_HEADERENTRY_TABLEBACK.CLICK", false]};
   this.EvtParms["REFRESH"] = [[{av:'Gx_mode',fld:'vMODE',pic:'@!',hsh:true}],[]];
   this.EvtParms["'CONFIRM'"] = [[{av:'Gx_mode',fld:'vMODE',pic:'@!',hsh:true},{av:'AV11Id',fld:'vID',pic:'ZZZZZZZZZZZ9'},{av:'AV12Name',fld:'vNAME',pic:''},{av:'AV5Dsc',fld:'vDSC',pic:''},{av:'AV8ExtId',fld:'vEXTID',pic:''},{ctrl:'vSECPOLID'},{av:'AV14SecPolId',fld:'vSECPOLID',pic:'ZZZZZZZZ9'}],[{ctrl:'WCMESSAGES'}]];
   this.EvtParms["'CANCEL'"] = [[{av:'AV11Id',fld:'vID',pic:'ZZZZZZZZZZZ9'},{av:'Gx_mode',fld:'vMODE',pic:'@!',hsh:true}],[]];
   this.EvtParms["'ROLEPERMISSIONS'"] = [[{av:'AV11Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV11Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["'ROLECHILDREN'"] = [[{av:'AV11Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV11Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["'DELETEROLE'"] = [[{av:'AV11Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV11Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["'EDIT'"] = [[{av:'AV11Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV11Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["GAM_HEADERENTRY_TABLEBACK.CLICK"] = [[],[]];
   this.EvtParms["'COPYROLE'"] = [[{av:'AV11Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[{ctrl:'WCMESSAGES'}]];
   this.EvtParms["ENTER"] = [[],[]];
   this.setVCMap("Gx_mode", "vMODE", 0, "char", 3, 0);
   this.Initialize( );
   this.setComponent({id: "WCMESSAGES" ,GXClass: null , Prefix: "W0087" , lvl: 1 });
});
gx.wi( function() { gx.createParentObj(this.gam_roleentry);});
